//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

public interface InstrumentFunc extends Cloneable, Comparable<MusicalInstrument> {

}
