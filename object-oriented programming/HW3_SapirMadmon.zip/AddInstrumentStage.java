//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.util.ArrayList;
import java.util.Arrays;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AddInstrumentStage extends Stage {
	private final int SPACE = 15, HIGHT = 300, WIDTH = 340, MIDDLE_PANE = 1;
	private VBox vboxAdd;
	private Scene scene;
	private final String types[] = new String[] { "Guitar", "Bass", "Flute", "Saxophone" };
	private ComboBox<String> comboBoxTypes;

	private AddInsGrid addInstrumentGrid = new AddSaxsophoneGrid();
	private AddGuitrGrid addGuitarGrid = new AddGuitrGrid();
	private AddBassGrid addBassGrid = new AddBassGrid();
	private AddFluteGrid addFluteGrid = new AddFluteGrid();

	private Button btnAdd;
	private ArrayList<MusicalInstrument> instruments;
	private CenterInstrumentPane centerPane;

	public AddInstrumentStage(ArrayList<MusicalInstrument> instruments, CenterInstrumentPane centerPane) {
		setTitle("Afeka Instruments - Add new Instruments");
		this.instruments = instruments;
		this.centerPane = centerPane;
		buildWindow();
	}

	private void buildWindow() {
		vboxAdd = new VBox(SPACE);
		scene = new Scene(vboxAdd, WIDTH, HIGHT);
		setScene(scene);
		vboxAdd.setAlignment(Pos.CENTER);
		vboxAdd.setPadding(new Insets(SPACE, SPACE, SPACE, SPACE));
		vboxAdd.setCursor(Cursor.HAND);

		buildComboBox();
		midVbox();
		buildButton();
		setAlwaysOnTop(false);
	}

	private void buildComboBox() {
		comboBoxTypes = new ComboBox<>(FXCollections.observableList(Arrays.asList(types)));
		comboBoxTypes.setPromptText("Choose Instruments Type Here");
		vboxAdd.getChildren().add(comboBoxTypes);
		comboBoxTypes.setOnAction(e -> selectIns());
	}

	private void selectIns() {
		btnAdd.setVisible(true);

		switch (comboBoxTypes.getValue()) {
		case "Guitar":
			vboxAdd.getChildren().set(MIDDLE_PANE, addGuitarGrid);
			break;

		case "Bass":
			vboxAdd.getChildren().set(MIDDLE_PANE, addBassGrid);
			break;

		case "Flute":
			vboxAdd.getChildren().set(MIDDLE_PANE, addFluteGrid);
			break;

		case "Saxophone":
			vboxAdd.getChildren().set(MIDDLE_PANE, addInstrumentGrid);
			break;
		}
	}

	private void midVbox() {
		vboxAdd.getChildren().add(new GridPane());
	}

	private void buildButton() {
		btnAdd = new Button("Add");
		vboxAdd.getChildren().add(btnAdd);
		btnAdd.setVisible(false);
		btnAdd.setOnAction(e -> CheckAdd());
	}

	private void CheckAdd() {
		try {
			instruments.add(((AddInsGrid) vboxAdd.getChildren().get(MIDDLE_PANE)).getInstrument());
			centerPane.setInstruments(instruments);
			hide();
		}
		catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setContentText(e.getMessage());
			alert.show();
		}
	}

	abstract class AddInsGrid extends GridPane {
		private Label labBrand = new Label("Brand:");
		protected TextField BrandField = new TextField();
		private Label labPrice = new Label("Price:");
		protected TextField PriceField = new TextField();
		private int row = 0;

		public AddInsGrid() {
			addRow(nextRowIndex(), labBrand, BrandField);
			addRow(nextRowIndex(), labPrice, PriceField);
			setAlignment(Pos.CENTER);
			setWidth(AddInstrumentStage.this.getWidth() - SPACE);
			setHeight(AddInstrumentStage.this.getHeight() / 2);
			setHgap(SPACE);
			setVgap(SPACE);
		}

		public abstract MusicalInstrument getInstrument();

		{
		}

		protected int nextRowIndex() {
			int temp = row;
			row++;
			return temp;
		}
	}

	abstract class AddStringInsGrid extends AddInsGrid {
		public Label labNumOfStrings = new Label("Number of strings: ");
		protected TextField numOfStringsField = new TextField();

		public AddStringInsGrid() {
			addRow(nextRowIndex(), labNumOfStrings, numOfStringsField);
			numOfStringsField.setPromptText("Ex:6");
			PriceField.setPromptText("Ex: 7500");
		}
	}

	class AddGuitrGrid extends AddStringInsGrid {
		private Label labguitarType = new Label("Guitar Type:");
		protected ComboBox<String> typeGuitarComboBox = new ComboBox<>(
				FXCollections.observableList(Arrays.asList(Guitar.GUITAR_TYPE)));

		public AddGuitrGrid() {
			addRow(nextRowIndex(), labguitarType, typeGuitarComboBox);
			typeGuitarComboBox.setPromptText("Type");
			BrandField.setPromptText("Ex: Gibson");
		}

		@Override
		public Guitar getInstrument() {
			return new Guitar(BrandField.getText(), Double.parseDouble(PriceField.getText()),
					Integer.parseInt(numOfStringsField.getText()),
					typeGuitarComboBox.getSelectionModel().getSelectedItem());
		}

	}

	class AddBassGrid extends AddStringInsGrid {
		private Label labFretless = new Label("Fretless:");
		private CheckBox fretlessCheckBox = new CheckBox();

		public AddBassGrid() {
			addRow(nextRowIndex(), labFretless, fretlessCheckBox);
			BrandField.setPromptText("Ex: Fender Jazz");
			numOfStringsField.setPromptText("Ex:4");
		}

		@Override
		public Bass getInstrument() {
			return new Bass(BrandField.getText(), Double.parseDouble(PriceField.getText()),
					Integer.parseInt(numOfStringsField.getText()), fretlessCheckBox.isSelected());
		}
	}

	abstract class AddWindInsGrid extends AddInsGrid {
		private Label labNumOfStrings = new Label("Material:");
		protected ComboBox<String> materialComboBox = new ComboBox<>(
				FXCollections.observableList(Arrays.asList(WindInstrument.WIND_INSTRUMENT_MATERIAL)));

		public AddWindInsGrid() {
			addRow(nextRowIndex(), labNumOfStrings, materialComboBox);
			materialComboBox.setPromptText("Material");
			BrandField.setPromptText("Ex: Levit");
			PriceField.setPromptText("Ex: 300");
		}
	}

	class AddFluteGrid extends AddWindInsGrid {
		private Label labNumOfStrings = new Label("Flute Type:");
		protected ComboBox<String> typeFluteComboBox = new ComboBox<>(
				FXCollections.observableList(Arrays.asList(Flute.FLUET_TYPE)));

		public AddFluteGrid() {
			addRow(nextRowIndex(), labNumOfStrings, typeFluteComboBox);
			typeFluteComboBox.setPromptText("Type");
		}

		@Override
		public Flute getInstrument() {
			return new Flute(BrandField.getText(), Double.parseDouble(PriceField.getText()),
					materialComboBox.getSelectionModel().getSelectedItem(),
					typeFluteComboBox.getSelectionModel().getSelectedItem());
		}
	}

	class AddSaxsophoneGrid extends AddInsGrid {
		@Override
		public Saxophone getInstrument() {
			return new Saxophone(BrandField.getText(), Double.parseDouble(PriceField.getText()));
		}
	}

}