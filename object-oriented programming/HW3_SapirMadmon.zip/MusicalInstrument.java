//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class MusicalInstrument implements InstrumentFunc {

	protected Number price;
	protected String brand; // Company name

	public MusicalInstrument(String brand, Number price) {
		try {
			setBrand(brand);
			setPrice(price);
		} catch (NumberFormatException e1) {
			throw new InputMismatchException("Price not found!");
		}
	}

	public MusicalInstrument(Scanner scanner) {
		String priceLine = null;
		Number price = 0;
		String brand;

		try {
			priceLine = scanner.next();
			price = Integer.parseInt(priceLine);
		} catch (NumberFormatException e) {
			try {
				price = Double.parseDouble(priceLine);
			} catch (NumberFormatException e1) {
				throw new InputMismatchException("Price not found!");
			}
		}
		setPrice(price);
		scanner.nextLine();
		brand = scanner.nextLine();
		setBrand(brand);
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public Number getPrice() {
		return price;
	}

	public void setPrice(Number price) {
		if (price.doubleValue() > 0)
			this.price = price;
		else
			throw new InputMismatchException("Price must be a positive number!");
	}

	protected boolean isValidType(String[] typeArr, String material) {
		for (int i = 0; i < typeArr.length; i++) {
			if (material.equals(typeArr[i])) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || !(o instanceof MusicalInstrument))
			return false;

		MusicalInstrument otherInstrument = (MusicalInstrument) o;

		return getPrice().doubleValue() == otherInstrument.getPrice().doubleValue()
				&& getBrand().equals(otherInstrument.getBrand());
	}

	@Override
	public int compareTo(MusicalInstrument o) {
		if (brand.compareTo(o.brand) == 0) {
			if (o.price.doubleValue() < this.price.doubleValue())
				return 1;
			else if (o.price.doubleValue() > this.price.doubleValue())
				return -1;
			else
				return 0;
		}
		return brand.compareTo(o.brand);
	}

	@Override
	public String toString() {
		return String.format("%-8s %-9s| Price: %7s,", getBrand(), getClass().getCanonicalName(), getPrice());
	}
}
