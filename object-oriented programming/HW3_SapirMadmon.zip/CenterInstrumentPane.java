//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.util.ArrayList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class CenterInstrumentPane extends GridPane {
	private final int SPACE = 25, PADDING = 10;
	private ArrayList<MusicalInstrument> instruments;
	private int i = 0;

	private Label labType = new Label("Type:");
	private TextField TypeField = new TextField();
	private Label labBrand = new Label("Brand:");
	private TextField BrandField = new TextField();
	private Label labPrice = new Label("Price:");
	private TextField PriceField = new TextField();
	private MusicalInstrument currentInstrument;

	public CenterInstrumentPane(ArrayList<MusicalInstrument> instruments) {
		this.instruments = instruments;
		setCurrentInstrument(currentInstrument);
		setAlignment(Pos.CENTER);
		setHgap(PADDING);
		setVgap(PADDING);
		setPadding(new Insets(SPACE, SPACE, SPACE, SPACE));

		add(labType, 0, 1);

		TypeField.setPromptText("No Items");
		TypeField.setEditable(false);
		add(TypeField, 1, 1);

		add(labBrand, 0, 2);

		BrandField.setPromptText("No Items");
		BrandField.setEditable(false);
		add(BrandField, 1, 2);

		add(labPrice, 0, 3);

		PriceField.setPromptText("No Items");
		PriceField.setEditable(false);
		add(PriceField, 1, 3);

		showInstrument();
	}

	public void ipp() {
		try {
			++i;
			if (i > instruments.size() - 1)
				i = 0;
			setCurrentInstrument(instruments.get(i));

			showInstrument(i);
		} catch (Exception e) {
		}
	}

	public void imm() {
		try {
			--i;
			if (i < 0)
				i = instruments.size() - 1;

			setCurrentInstrument(instruments.get(i));
			showInstrument(i);
		} catch (Exception e) {
		}
	}

	public void showInstrument() {
		showInstrument(0);
	}

	private void showInstrument(int i) {

		if (instruments.isEmpty()) {
			PriceField.clear();
			BrandField.clear();
			TypeField.clear();
		} else {
			PriceField.setText(instruments.get(i).getPrice() + "");
			BrandField.setText(instruments.get(i).getBrand() + "");
			TypeField.setText(instruments.get(i).getClass().getSimpleName() + "");
		}
	}

	public int getCurrentInstrumentIndex() {
		return i;
	}

	public MusicalInstrument getCurrentInstrument() {
		return currentInstrument = instruments.get(i);
	}

	public ArrayList<MusicalInstrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(ArrayList<MusicalInstrument> instruments) {
		this.instruments = instruments;
		i = 0;
		showInstrument();
	}

	public void setCurrentInstrument(MusicalInstrument currentInstrument) {
		this.currentInstrument = currentInstrument;
	}

}
