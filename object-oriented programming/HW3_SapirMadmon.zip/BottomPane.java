//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javafx.animation.KeyFrame;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class BottomPane extends VBox {
	private final int SPACE = 12;
	private Button btnAdd;
	private Button btnDelete;
	private Button btnClear;
	private HBox btnPane;
	private HBox textPane;
	private ArrayList<MusicalInstrument> instruments;
	private AddInstrumentStage addInstrumentWindow;
	private CenterInstrumentPane centerPane;

	public BottomPane(ArrayList<MusicalInstrument> instruments, AddInstrumentStage addInstrumentWindow,
			CenterInstrumentPane centerPane) {
		this.instruments = instruments;
		this.addInstrumentWindow = addInstrumentWindow;
		this.centerPane = centerPane;
		btnPane = getBtnPane();
		textPane = getTextPane();
		setPadding(new Insets(SPACE, SPACE, SPACE, SPACE));
		getChildren().addAll(btnPane, textPane);
		setAlignment(Pos.CENTER);
	}

	public HBox getBtnPane() {
		btnAdd = new Button("Add");
		btnDelete = new Button("Delete");
		btnClear = new Button("Clear");
		HBox hBox = new HBox(SPACE);

		hBox.getChildren().add(btnAdd);
		hBox.getChildren().add(btnDelete);
		hBox.getChildren().add(btnClear);
		hBox.setAlignment(Pos.CENTER);

		btnAdd.setOnAction(e -> addInstrument());
		btnClear.setOnAction(e -> clearmethod());
		btnDelete.setOnAction(e -> deleteInstrument());

		return hBox;
	}

	public void deleteInstrument() {
		if (instruments.size() > 0)
			instruments.remove(centerPane.getCurrentInstrument());
		centerPane.setInstruments(instruments);
	}

	public void addInstrument() {
		addInstrumentWindow = new AddInstrumentStage(instruments, centerPane);
		addInstrumentWindow.show();
	}

	public void clearmethod() {
		instruments.removeAll(instruments);
		centerPane.setInstruments(instruments);
	}

	public HBox getTextPane() {
		Text textMoving = new Text();
		LocalDate nowDate = LocalDate.now();
		Timeline nowTime = new Timeline(new KeyFrame(Duration.millis(1), e -> {
			textMoving.setText(nowDate + " " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))
					+ " Afeka Instruments Music Store $$$ ON SALE!!! $$$ Guitars, Basses, Flutes, Saxsophones and more!");
		}));
		nowTime.setCycleCount(Timeline.INDEFINITE);
		nowTime.play();

		HBox hBox = new HBox(SPACE);
		hBox.setPadding(new Insets(SPACE, SPACE, SPACE, SPACE));
		textMoving.setFill(Color.RED);
		textMoving.setFont(Font.font("Courier", FontWeight.BOLD, 13));
		hBox.getChildren().add(textMoving);

		PathTransition animation = new PathTransition(Duration.seconds(10), new Line(900, 0, 0, 0), textMoving);

		animation.setCycleCount(Timeline.INDEFINITE);
		animation.setAutoReverse(true);
		animation.play();

		textMoving.setOnMouseEntered(e -> {
			animation.pause();
		});
		textMoving.setOnMouseExited(e -> {
			animation.play();
		});
		return hBox;
	}
}
