//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.io.File;
import java.util.ArrayList;
import java.util.Optional;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.KeyCode;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AfekaInstrumentsGui extends Application {

	private ArrayList<MusicalInstrument> instruments;
	private BorderPane root;
	private TopSearchPane topPane;
	private CenterInstrumentPane centerPane;
	private BottomPane bottomPane;
	private AddInstrumentStage addInstrumentStage;

	@Override
	public void start(Stage stage) throws Exception {
		root = new BorderPane();
		this.instruments = new ArrayList<>();
		File file = getInstrumentsFileFromDialogText();
		AfekaInstruments.loadInstrumentsFromFile(file, instruments);
		this.centerPane = new CenterInstrumentPane(instruments);
		this.addInstrumentStage = new AddInstrumentStage(instruments, centerPane);
		this.topPane = new TopSearchPane(instruments, centerPane);
		this.bottomPane = new BottomPane(instruments, addInstrumentStage, centerPane);

		root.setTop(topPane);
		root.setCenter(centerPane);
		root.setBottom(bottomPane);
		setupBtnLeftRight();

		Scene scene = new Scene(root);
		scene.setOnKeyPressed(e -> {
			if (e.getText().equalsIgnoreCase("A"))
				bottomPane.addInstrument();
			else if (e.getCode() == KeyCode.DELETE)
				bottomPane.deleteInstrument();
			else if (e.getCode() == KeyCode.ENTER)
				topPane.searchInstrument();
		});

		stage.setTitle("Afeka Instruments Music Store");
		stage.setScene(scene);
		stage.setAlwaysOnTop(false);
		stage.show();
	}

	public File getInstrumentsFileFromDialogText() {
		boolean stopLoop = true;
		TextInputDialog steamFileDialog = new TextInputDialog("");
		steamFileDialog.setTitle("confirmation");
		steamFileDialog.setHeaderText("Load Instruments From File");
		steamFileDialog.setContentText("Please enter file name: ");

		Alert alert = new Alert(AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText("File Error!");
		alert.setContentText("cannot read file, please try again");

		Optional<String> steamFile;
		File file;
		try {
			do {
				steamFile = steamFileDialog.showAndWait();
				file = new File(steamFile.get());
				stopLoop = file.exists() && file.canRead();

				if (!stopLoop)
					alert.showAndWait();
			} while (!stopLoop);
			return file;
		} catch (Exception e) {
			System.exit(0);
			alert.show();
		}
		return null;
	}

	private void setupBtnLeftRight() {
		Button btnLeft = new Button("<");
		Button btnRight = new Button(">");
		VBox btttomLeft = new VBox(btnLeft);
		VBox btttomRight = new VBox(btnRight);
		btttomLeft.setAlignment(Pos.CENTER);
		btttomRight.setAlignment(Pos.CENTER);
		btnLeft.setOnAction(e -> centerPane.imm());
		btnRight.setOnAction(e -> centerPane.ipp());
		btttomLeft.setPadding(new Insets(5));
		btttomRight.setPadding(new Insets(5));
		root.setLeft(btttomLeft);
		root.setRight(btttomRight);
	}

	public static void main(String[] args) {
		launch(args);
	}
}
