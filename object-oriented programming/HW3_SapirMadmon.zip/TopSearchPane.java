//Sapir Madmon  ID:209010230
package HW3_SapirMadmon;

import java.util.ArrayList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;

public class TopSearchPane extends HBox {
	private final int SPACE = 15;
	private TextField searchField;
	private Button btnSearch;
	private ArrayList<MusicalInstrument> instruments;
	private ArrayList<MusicalInstrument> instrumentsSearched;
	private CenterInstrumentPane centerPane;

	public TopSearchPane(ArrayList<MusicalInstrument> instruments, CenterInstrumentPane centerPane) {
		this.instruments = instruments;
		this.instrumentsSearched = new ArrayList<>();
		this.centerPane = centerPane;
		setSpacing(SPACE);

		setPadding(new Insets(SPACE, SPACE, SPACE, SPACE));
		searchField = new TextField();
		searchField.setPrefWidth(700);
		searchField.setPromptText("search...");
		getChildren().add(searchField);
		btnSearch = new Button("Go!");
		btnSearch.setOnAction(e -> searchInstrument());
		getChildren().add(btnSearch);
		setAlignment(Pos.CENTER);
	}

	public void searchInstrument() {
		this.instrumentsSearched = new ArrayList<>();
		for (int i = 0; i < instruments.size(); i++) {
			String str = instruments.get(i).toString();
			String subStr = searchField.getText();
			if (str.contains(subStr)) {
				instrumentsSearched.add(instruments.get(i));
			}
		}
		this.centerPane.setInstruments(instrumentsSearched);
	}

}
