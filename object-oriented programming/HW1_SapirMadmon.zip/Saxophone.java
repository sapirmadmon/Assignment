//import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Saxophone extends WindInstruments 
{
	
	public Saxophone(double price, String companyName) throws InputMismatchException 
	{
		super(price, companyName);
		if(!super.getTypeWind().equals(super.getArrTypeWind()[0]))
		{
			throw new InputMismatchException("Error! Saxophone must be made of metal");  
		}
	}

	public Saxophone(Scanner scanner) throws InputMismatchException 
	{
		super(scanner);
		if(!super.getTypeWind().equals(super.getArrTypeWind()[0]))
		{
			throw new InputMismatchException("Error! Saxophone must be made of metal"); 
		}
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (!super.equals(obj))
			return false;
		if(!(obj instanceof Saxophone))
			return false;
		return true;
	}

	@Override
	public String toString() 
	{
		return super.toString();
	}

}
