import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AfekaInstruments // Main Department
{
	public static void main(String[] args) throws Exception 
	{
		ArrayList<Musicalnstruments> Instruments = new ArrayList<Musicalnstruments>();
		Scanner userInput = new Scanner(System.in);
		boolean ifFileOk = false;
		while (!ifFileOk) 
		{
			try {
				System.out.println("please enter instruments file name / path:");
				String inputFile = userInput.next();
				File f = new File(inputFile);
				Scanner s = new Scanner(f);
				ifFileOk = true;
				
				addAllInstruments(Instruments,addGuitar(s));
				addAllInstruments(Instruments,addBassGuitar(s));
				addAllInstruments(Instruments,addFlute(s));
				addAllInstruments(Instruments,addSaxophone(s));
				
				if(Instruments.isEmpty())
				   {
					System.out.println("Instruments loaded from file successfully!\n");
					throw new ArrayIndexOutOfBoundsException("There are no instruments in the store currently");
			       }

				printInstruments(Instruments); // Printing the instrument array

				if(Instruments.size()>0)
				  {
					System.out.println("\nDifferent Instruments: " + getNumOfDifferentElements(Instruments));
					System.out.println("\nMost Expensive Instrument:\n" + getMostExpensiveInstrument(Instruments));
				  }		
			
			    }
			catch (FileNotFoundException e) 
			{
				System.err.println("File Error! Please try again:");
				userInput.nextLine();
			}
			catch (ArrayIndexOutOfBoundsException e3) 
			{
				System.out.println(e3.getMessage());
			} 
			catch (InputMismatchException e2) 
			{
				System.err.println(e2.getMessage());
			} 
			catch (IllegalArgumentException e1) 
			{
				System.err.println(e1.getMessage());
			}
		
		}

	}

		public static ArrayList addGuitar(Scanner s) throws Exception //help method
		{
			ArrayList<Musicalnstruments> guitar = new ArrayList<Musicalnstruments>();
			int numOfIns=s.nextInt();
			s.nextLine();
			for (int i = 0; i < numOfIns; i++) 
			{
				guitar.add(new Guitar(s));
			}
			return guitar;
			
		}
	
		public static ArrayList addBassGuitar(Scanner s) throws Exception  //help method
		{
			ArrayList<Musicalnstruments> bassGuitar = new ArrayList<>();
			int numOfIns=s.nextInt();
			s.nextLine();
			for (int i = 0; i < numOfIns; i++) {
				bassGuitar.add(new Bass(s));
			}
			return bassGuitar;
		}
	
		public static ArrayList addFlute(Scanner s) throws Exception //help method
		{
			ArrayList<Musicalnstruments> flute = new ArrayList<>();
			int numOfIns=s.nextInt();
			s.nextLine();
			for (int i = 0; i < numOfIns; i++) 
			{
				flute.add(new Fluet(s));
			}
			return flute;
	
		}
	
		public static ArrayList addSaxophone(Scanner s) throws Exception //help method
		{
			ArrayList<Musicalnstruments> Saxophone = new ArrayList<>();
			int numOfIns=s.nextInt();
			for (int i = 0; i < numOfIns; i++) 
			{
				Saxophone.add(new Saxophone(s));
			}
			return Saxophone;
		}

		
	public static ArrayList addAllInstruments(ArrayList arr1, ArrayList arr2) 
	{
		ArrayList<Musicalnstruments> allInstruments=arr1;
		for (int i = 0; i < arr2.size(); i++)
			arr1.add(arr2.get(i));
		return allInstruments;
	}

	public static void printInstruments(ArrayList arrDynamic) 
	{
		System.out.println("\nInstruments loaded from file successfully!\n");
		for (int i = 0; i < arrDynamic.size(); i++)
			System.out.println(arrDynamic.get(i));	
	}

	public static Musicalnstruments getMostExpensiveInstrument(ArrayList<Musicalnstruments> arrInstruments) 
	{
		int indexMax = 0;
		double maxPrice = arrInstruments.get(0).getPrice();
		for (int i = 1; i < arrInstruments.size(); i++) {
			double priceCurrent = arrInstruments.get(i).getPrice();
			if (priceCurrent > maxPrice) {
				maxPrice = priceCurrent;
				indexMax = i;
			}
		}
		return arrInstruments.get(indexMax);
	}

	public static int getNumOfDifferentElements(ArrayList arr) 
	{
		ArrayList<Musicalnstruments> newList = new ArrayList<>(arr); // duplicate arrayList
		int size = newList.size();
		for (int i = 0; i < size - 1; i++) 
		{
			for (int j = i + 1; j < size; j++) 
			{
				if (arr.get(i).getClass().getSimpleName().equals(arr.get(j).getClass().getSimpleName()))
					if (arr.get(i).equals(arr.get(j))) 
					{
						newList.remove(j);
						j--;
						size--;
					}
			}
		}
		return newList.size();
	}
}
