//import java.io.FileNotFoundException;
import java.util.InputMismatchException;
//import java.util.Arrays;
import java.util.Scanner;

public class WindInstruments extends Musicalnstruments
{
	private final String[] arrTypeWind={"Metal","Plastic", "Wood"}; //final array of type wind 
	private String TypeWind;

	public WindInstruments(double price, String companyName) 
	{
		super(price, companyName);
		setTypeWind(TypeWind);
	}

	public WindInstruments(Scanner scanner) throws InputMismatchException
	{
		super(scanner);
		String type=scanner.nextLine();
		while(type.equals(""))
		{
			type=scanner.nextLine();
		}
		setTypeWind(type);
	}

	public String getTypeWind() 
	{
		return TypeWind;
	}

	public void setTypeWind(String typeWind) throws InputMismatchException
	{
		for(int i=0; i<arrTypeWind.length; i++)
			if(arrTypeWind[i].equals(typeWind))
			{
				this.TypeWind = typeWind;
				return;
			}
		throw new InputMismatchException("The type of wind does not exist!");
	}

	public String[] getArrTypeWind() 
	{
		return arrTypeWind;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (!super.equals(obj))
			return false;
		if(!(obj instanceof WindInstruments))
			return false;
		return(((WindInstruments)obj).getTypeWind().equals(getTypeWind()));
	}

	@Override
	public String toString() 
	{
		return super.toString()+String.format(" Made of:\t%9s%c", getTypeWind(),'|');
	}

}
