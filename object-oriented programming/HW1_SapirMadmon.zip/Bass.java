import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Bass extends StringInstrument
{
	private boolean fretless;

	public Bass(double price, String companyName, int numOfString, boolean fretless) throws IllegalArgumentException
	{
		super(price, companyName, numOfString);
		try{
			setFretless(fretless);
		   }
		
		catch(IllegalArgumentException e)
	       {
			System.err.println("whether a bass is fretless or not is boolean,any other string then \"True\" or \"False\" is not acceptable");
		   }
		
		if(this.getNumOfString()<4 || this.getNumOfString()>6)
			throw new InputMismatchException("Bass number of strings is a number between 4 and 6");
	}

	public Bass(Scanner scanner) throws Exception  
	{
		super(scanner);
		try {
			if(!(this.getNumOfString()<4 || this.getNumOfString()>6))
		    	{
				this.fretless=scanner.nextBoolean();
		    	}
			else
				throw new IllegalArgumentException("Bass number of strings is a number between 4 and 6");
	    	}
		catch(InputMismatchException e)
		{
			System.err.println("whether a bass is fretless or not is boolean,any other string then \"True\" or \"False\" is not acceptable");
			System.exit(0);
		}
	}

	public boolean isFretless() 
	{
		return fretless;
	}

	public void setFretless(boolean fretless) 
	{
		this.fretless=fretless;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if(!super.equals(obj))
			return false;
		if(!(obj instanceof Bass))
			return false;
		return ((Bass)obj).fretless == fretless;
	}

	@Override
	public String toString() 
	{
		String fretlessYN="";
		if(fretless==true)
			fretlessYN="Yes";
		else if(fretless==false)
			fretlessYN="No";
		return super.toString()+String.format(" Fretless: %s",fretlessYN);
	}

}

