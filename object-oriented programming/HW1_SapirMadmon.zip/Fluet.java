//import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Fluet extends WindInstruments 
{
	final private String[] arrtypeFlute={"Fluet", "Recorder", "Fluet Bass"};
	private String typeFlute;

	public Fluet(double price, String companyName, String typeFlute)  
	{
		super(price, companyName);
		setTypeFlute(typeFlute);
	}

	public Fluet(Scanner scanner) throws InputMismatchException  
	{
		super(scanner);
		String typeF=scanner.nextLine();
		while(typeF.equals(""))
		{
			typeF=scanner.nextLine();
		}
		setTypeFlute(typeF);
	}

	public String getTypeFlute() 
	{
		return typeFlute;
	}

	public void setTypeFlute(String typeFlute) throws InputMismatchException 
	{
		for(int i=0; i<arrtypeFlute.length; i++)
		{
			if(arrtypeFlute[i].equals(typeFlute))
			{
				this.typeFlute = typeFlute;
				return;
			}
		}
		throw new InputMismatchException("The type of flute does not exist!");
	}

	public String[] getArrtypeFlute() 
	{
		return arrtypeFlute;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (!super.equals(obj))
			return false;
		if(!(obj instanceof Fluet))
			return false;
		return(((Fluet)obj).getTypeFlute().equals(getTypeFlute()));
	}

	@Override
	public String toString() 
	{
		return super.toString()+String.format(" Type: %s", getTypeFlute());
	}

}
