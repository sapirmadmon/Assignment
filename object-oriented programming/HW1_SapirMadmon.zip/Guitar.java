//import java.io.FileNotFoundException;
//import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Guitar extends StringInstrument
{
	final private String[] arrtypeGuitar={"Electric", "Acoustic", "Classic"};
	private String typeGuiter;

	public Guitar(double price, String companyName, int numOfString,String typeGuiter)  
	{
		super(price, companyName, numOfString);
		setTypeGuiter(typeGuiter);
	}

	public Guitar(Scanner scanner) throws InputMismatchException 
	{
		super(scanner);
		String type=scanner.nextLine();
		while(type.equals(""))
		{
			type=scanner.nextLine();
		}
		setTypeGuiter(type);
		if(getNumOfString()!=6)
		{
			if(!typeGuiter.equals(arrtypeGuitar[0]))
			{
				throw new InputMismatchException(typeGuiter + " Guitars have 6 strings, not "+getNumOfString());
			}
			if((getNumOfString()<6)||(getNumOfString()>8))
			{
				throw new InputMismatchException("The number of strings of Electric guitar is between 6 and 8");
			}
		}
	}

	public String getTypeGuiter() 
	{
		return typeGuiter;
	}

	public void setTypeGuiter(String typeGuiter) throws InputMismatchException 
	{
		for(int i = 0 ; i < arrtypeGuitar.length ; i++)
		{
			if(arrtypeGuitar[i].equals(typeGuiter))
			{
				this.typeGuiter = typeGuiter;
				return;
			}
		}
		throw new InputMismatchException("The type of guitar does not exist!");
	}
	
	@Override
	public boolean equals(Object obj) 
	{
		if (!super.equals(obj))
			return false;
		if(!(obj instanceof Guitar))
			return false;
		return(((Guitar)obj).getTypeGuiter().equals(getTypeGuiter()));
	}

	@Override
	public String toString() 
	{
		return super.toString()+String.format(" Type: %s", getTypeGuiter());
	}

}
