//import java.io.FileNotFoundException;
import java.util.Scanner;

public class StringInstrument extends Musicalnstruments
{
	private int numOfString; //number of strings
	
	public StringInstrument(double price, String companyName, int numOfString) 
	{
		super(price, companyName);
		this.numOfString = numOfString;
	}
	
	public StringInstrument(Scanner scanner)  
	{
		super(scanner);
		numOfString=scanner.nextInt();
		setNumOfString(numOfString);
	}

	public int getNumOfString() 
	{
		return numOfString;
	}

	public void setNumOfString(int numOfString) 
	{
		this.numOfString = numOfString;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (!super.equals(obj))
			return false;
		if(!(obj instanceof StringInstrument))
			return false;
		return(((StringInstrument)obj).getNumOfString() == getNumOfString());
	}

	@Override
	public String toString()
	{
		return super.toString() + String.format(" Number of strings: %d%c",getNumOfString(),'|');
	}

}
