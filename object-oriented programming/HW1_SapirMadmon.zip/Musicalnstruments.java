//import java.io.File;
//import java.io.FileNotFoundException;
import java.util.Scanner;


public class Musicalnstruments 
{
	private double price; 
	private String companyName;

	public Musicalnstruments(double price, String companyName) 
	{
		this.price = price;
		this.companyName = companyName;
	}
	
	public Musicalnstruments (Scanner scanner) throws NumberFormatException
	{
		try{
			int tempPrice=Integer.parseInt(scanner.next());
			price=(double)(tempPrice);
			setPrice(price);
			companyName=scanner.nextLine();	

			while(companyName.equals(""))
				companyName=scanner.nextLine();

			setCompanyName(companyName);
		   }
		catch(NumberFormatException er)
		{
			System.err.println("Invalid file");
			System.exit(0);
		}
	} 

	public void setPrice(double price) throws IllegalArgumentException 
	{
		if(price>0)
			this.price = price;
		else 
			throw new IllegalArgumentException ("Price must be a positive number!");
	}

	public double getPrice() 
	{
		return price;
	}

	public String getCompanyName() 
	{
		return companyName;
	}
	public void setCompanyName(String companyName) 
	{
		this.companyName = companyName;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (obj == null)
			return false;
		if(!(obj instanceof Musicalnstruments))
			return false;
		return(((Musicalnstruments)obj).getPrice() == getPrice()) &&
				(((Musicalnstruments)obj).getCompanyName().equals(getCompanyName()));
	}

	@Override
	public String toString() 
	{
		return String.format("%-9s %-8s\t %c Price:%10.2f,", companyName,getClass().getCanonicalName(),'|',price);
	}


}
