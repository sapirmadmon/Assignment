//Sapir Madmon  ID:209010230

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
//import javax.swing.text.html.InlineView;

public class AfekaInstruments 
{
	public static void main(String[] args) 
	{
		ArrayList<MusicalInstrument> allInstruments = new ArrayList<MusicalInstrument>();
		Scanner consoleScanner = new Scanner(System.in);
		File file = getInstrumentsFileFromUser(consoleScanner);

		loadInstrumentsFromFile(file, allInstruments);

		if(allInstruments.size() == 0) 
		{
			System.out.println("There are no instruments in the store currently");
			consoleScanner.close();
			return;
		}

		printInstruments(allInstruments);
		int different = getNumOfDifferentElements(allInstruments);
		System.out.println("\nDifferent Instruments: " + different);

		MusicalInstrument mostExpensive = getMostExpensiveInstrument(allInstruments);

		System.out.println("\nMost Expensive Instrument:\n" + mostExpensive);

		startInventoryMenu(allInstruments);
		consoleScanner.close();
	}

	public static File getInstrumentsFileFromUser(Scanner consoleScanner)
	{
		boolean stopLoop = true;
		File file;

		do {
			System.out.println("Please enter instruments file name / path:");
			String filepath = consoleScanner.nextLine();
			file = new File(filepath);
			stopLoop = file.exists() && file.canRead();

			if(!stopLoop)
				System.out.println("\nFile Error! Please try again\n\n");
		} while (!stopLoop);

		return file;
	}

	public static void loadInstrumentsFromFile(File file, ArrayList<MusicalInstrument> allInstruments)
	{
		Scanner scanner = null;
		try 
		{
			scanner = new Scanner(file);

			addAllInstruments(allInstruments ,loadGuitars(scanner));

			addAllInstruments(allInstruments ,loadBassGuitars(scanner));

			addAllInstruments(allInstruments ,loadFlutes(scanner));

			addAllInstruments(allInstruments ,loadSaxophones(scanner));
		}
		catch (InputMismatchException | IllegalArgumentException ex)
		{
			System.err.println("\n"+ ex.getMessage());
			System.exit(1);
		}
		catch (FileNotFoundException ex)
		{
			System.err.println("\nFile Error! File was not found");
			System.exit(2);
		} 
		finally 
		{
			scanner.close();
		}

		System.out.println("\nInstruments loaded from file successfully!\n");
	}

	public static ArrayList<MusicalInstrument> loadGuitars(Scanner scanner)
	{
		int numOfInstruments = scanner.nextInt();
		ArrayList<MusicalInstrument> guitars = new ArrayList<MusicalInstrument>(numOfInstruments);

		for(int i = 0; i < numOfInstruments ; i++)
			guitars.add(new Guitar(scanner));

		return guitars;
	}

	public static ArrayList<MusicalInstrument> loadBassGuitars(Scanner scanner)
	{
		int numOfInstruments = scanner.nextInt();
		ArrayList<MusicalInstrument> bassGuitars = new ArrayList<MusicalInstrument>(numOfInstruments);

		for(int i = 0; i < numOfInstruments ; i++)
			bassGuitars.add(new Bass(scanner));

		return bassGuitars;
	}

	public static ArrayList<MusicalInstrument> loadFlutes(Scanner scanner)
	{
		int numOfInstruments = scanner.nextInt();
		ArrayList<MusicalInstrument> flutes = new ArrayList<MusicalInstrument>(numOfInstruments);

		for(int i = 0; i < numOfInstruments ; i++)
			flutes.add(new Flute(scanner));

		return flutes;
	}

	public static ArrayList<MusicalInstrument> loadSaxophones(Scanner scanner)
	{
		int numOfInstruments = scanner.nextInt();
		ArrayList<MusicalInstrument> saxophones = new ArrayList<MusicalInstrument>(numOfInstruments);

		for(int i = 0; i < numOfInstruments ; i++)
			saxophones.add(new Saxophone(scanner));

		return saxophones;
	}

	public static void addAllInstruments(ArrayList<MusicalInstrument> instruments, ArrayList<MusicalInstrument> moreInstruments)
	{
		for(int i = 0 ; i < moreInstruments.size() ; i++)
		{
			instruments.add(moreInstruments.get(i));
		}
	}

	public static void printInstruments(ArrayList<MusicalInstrument> instruments)
	{
		for(int i = 0 ; i < instruments.size() ; i++)
			System.out.println(instruments.get(i));
	}

	public static int getNumOfDifferentElements(ArrayList<MusicalInstrument> instruments)
	{
		int numOfDifferentInstruments;
		ArrayList<MusicalInstrument> differentInstruments = new ArrayList<MusicalInstrument>();
		System.out.println();

		for(int i = 0 ; i < instruments.size() ; i++)
		{
			if(!differentInstruments.contains((instruments.get(i))))
			{
				differentInstruments.add(instruments.get(i));
			}
		}

		if(differentInstruments.size() == 1)
			numOfDifferentInstruments = 0;

		else
			numOfDifferentInstruments = differentInstruments.size();

		return numOfDifferentInstruments;
	}

	public static MusicalInstrument getMostExpensiveInstrument(ArrayList<MusicalInstrument> instruments)
	{
		double maxPrice = 0;
		MusicalInstrument mostExpensive = (MusicalInstrument) instruments.get(0);

		for(int i = 0 ; i < instruments.size() ; i++)
		{
			MusicalInstrument temp = (MusicalInstrument)instruments.get(i);

			if(temp.getPrice().doubleValue() > maxPrice)
			{
				maxPrice = temp.getPrice().doubleValue();
				mostExpensive = temp;
			}
		}
		return mostExpensive;
	}

	public static void startInventoryMenu (ArrayList<MusicalInstrument> arrIns)  
	{
		AfekaInventory<MusicalInstrument> inventory = new AfekaInventory<MusicalInstrument>();
		boolean stop = false;

		Scanner scanner = new Scanner(System.in);
		do {
			System.out.print("\n-------------------------------------------------------------------------\nAFEKA MUSICAL INSTRUMENT INVENTORY MENU\n-------------------------------------------------------------------------\n"
					+ "1. Copy All String Instruments To Inventory \n"
					+ "2. Copy All Wind Instruments To Inventory \n"
					+ "3. Sort Instruments By Brand And Price \n"
					+ "4. Search Instrument By Brand And Price \n"
					+ "5. Delete Instrument \n"
					+ "6. Delete all Instruments \n"
					+ "7. Print Inventory Instruments \n"
					+ "Choose your option or any other key to EXIT \n\n"
					+ "Your Option: ");
			String option = scanner.next();

			Number price = 0;
			int index;
			String brandInput,inputYN,priceInput = null;

			switch (option) 
			{
			case "1":
				inventory.addAllStringInstruments(arrIns, inventory.getArrIns());
				System.out.println("\nAll String Instruments Added Successfully!\n");
				break;

			case "2":
				inventory.addAllWindInstruments(arrIns, inventory.getArrIns());
				System.out.println("\nAll Wind Instruments Added Successfully!\n");
				break;

			case "3":
				inventory.sortByBrandAndPrice(inventory.getArrIns());
				System.out.println("\nInstruments Sorted Successfully!\n");
				break;

			case "4":
				System.out.println("\nSEARCH INSTRUMENT:");
				System.out.print("Brand:");
				brandInput = scanner.next();
				System.out.print("\nPrice:");
				try 
				{
					priceInput=scanner.next();
					price=Integer.parseInt(priceInput);
				}
				catch (NumberFormatException e1) 
				{
					try 
					{
						price=Double.parseDouble(priceInput);
					}
					catch (NumberFormatException e2) 
					{
					}

				}	
				index=inventory.binnarySearchByBrandAndPrice(inventory.getArrIns(), brandInput, price);

				if(index<0)
					System.out.println("Instrument Not Found!\n");
				else 
					System.out.printf("Result:\n\t%s\n", inventory.getArrIns().get(index)); 
				break;

			case "5": 
				System.out.println("\nDELETE INSTRUMENT:");
				System.out.print("Brand:");
				brandInput=scanner.next();
				System.out.print("\nPrice:");
				try 
				{
					priceInput=scanner.next();
					price=Integer.parseInt(priceInput);
				}
				catch (NumberFormatException e1) 
				{
					try 
					{
						price=Double.parseDouble(priceInput);
					}
					catch (NumberFormatException e2) 
					{
					}
				}
				index=inventory.binnarySearchByBrandAndPrice(inventory.getArrIns(), brandInput, price);
				if(index<0)
					System.out.println("Can not delete!\nInstrument Not Found!\n");
				else 
				{
					System.out.println("Result:");
					System.out.println(inventory.getArrIns().get(index));
					System.out.print("Are You Sure?(Y/N)");
					inputYN=scanner.next();
					if(inputYN.equals("Y") || inputYN.equals("y"))
					{
						inventory.removeInstrument(inventory.getArrIns(), inventory.getArrIns().get(index));
						System.out.println("Instrument Deleted Successfully!");
					}
					else if(inputYN.equals("N") || inputYN.equals("n"))
						System.out.println("Operation Canceled!");
				}
				break;

			case "6":
				System.out.println("DELETE ALL INSTRUMENTS:\n");
				System.out.print("Are You Sure?(Y/N)");
				inputYN=scanner.next();
				if(inputYN.equals("Y") || inputYN.equals("y"))
				{
					inventory.removeAll(inventory.getArrIns());
					System.out.println("\nAll Instruments Deleted Successfully!\n");
				}
				else if(inputYN.equals("N") || inputYN.equals("n"))
					System.out.println("Operation Canceled!");
				break;

			case "7":
				System.out.println(inventory);
				break;

			case "\n":
				break;

			default:
				stop=true;
				System.out.println("Finished!");
				break;
			}

		}while(!stop);
		scanner.close();
	}
}
