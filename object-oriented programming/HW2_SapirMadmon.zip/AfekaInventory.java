//Sapir Madmon  ID:209010230

import java.util.ArrayList;

public class AfekaInventory<E extends MusicalInstrument> implements InventoryManageable<E>
{
	private ArrayList<E> arrIns;
	private double totalPrice;
	private boolean isSorted;

	public AfekaInventory() //constructor 1 
	{
		setArrIns(new ArrayList<E>());	
	}

	public AfekaInventory(ArrayList<E> arr) //constructor 2
	{
		setArrIns(arr);
	}

	public void setArrIns(ArrayList<E> arrIns) 
	{
		this.arrIns = arrIns;
		setIsSorted(false);
		getTotalPrice();
	}

	public ArrayList<E> getArrIns() 
	{
		return arrIns;
	}

	public double getTotalPrice() 
	{
		return totalPrice;
	}

	public void setTotalPrice()
	{
		double sumTotal=0;
		if(this.arrIns!=null)
			for(int i=0; i<arrIns.size(); i++)
				sumTotal+=arrIns.get(i).getPrice().doubleValue();
		this.totalPrice = sumTotal;
	}

	public boolean isSorted() 
	{
		return isSorted;
	}


	public void setIsSorted(boolean isInventorySort) 
	{
		this.isSorted = isInventorySort;
	}


	public<N1 extends Number, N2 extends Number> double SumGeneric(N1 a, N2 b)
	{
		return a.doubleValue()+b.doubleValue();
	}

	@Override
	public void addAllStringInstruments(ArrayList<? extends MusicalInstrument> src,ArrayList<? super MusicalInstrument> to) 
	{
		for(int i=0; i<src.size(); i++)
		{
			if(src.get(i) instanceof StringInstrument)
				to.add((StringInstrument)src.get(i));
		}
		setIsSorted(false);
		setTotalPrice();
	}


	@Override
	public void addAllWindInstruments(ArrayList<? extends MusicalInstrument> src,ArrayList<? super MusicalInstrument> to) 
	{
		for(int i=0; i<src.size(); i++)
		{
			if(src.get(i) instanceof WindInstrument)
				to.add((WindInstrument)src.get(i));
		}
		setIsSorted(false);
		setTotalPrice();	
	}

	@Override
	public void sortByBrandAndPrice(ArrayList<E> arr) 
	{
		for(int i=0; i<arr.size(); i++)
		{
			for(int j=i; j<arr.size(); j++)
			{
				if(arr.get(i).compareTo(arr.get(j))>0) 
				{
					E temp=arr.get(i);
					arr.set(i, arr.get(j));
					arr.set(j, temp);
				}
			}
		}
		setIsSorted(true); 
	}

	@Override
	public int binnarySearchByBrandAndPrice(ArrayList<E> arr, String companyName,Number price)	
	{
		//With the consent of the lecturers, can be sorted before the binary search.
		//With the consent of the lecturers, if no musical instrument is found, he will return -1.
		if(!isSorted())
			sortByBrandAndPrice(arr);

		int low = 0;
		int high = arr.size() - 1;
		int middle = 0;
		while (low <= high)	
		{
			middle = (low + high)/2; 
			if (companyName.compareTo(arr.get(middle).getBrand()) == 0)
			{
				if((price.doubleValue()-arr.get(middle).getPrice().doubleValue())<0)
					high=middle-1;
				else
					if((price.doubleValue()-arr.get(middle).getPrice().doubleValue())==0)
						return middle;
					else 
						low=middle+1;
			}    
			else if (companyName.compareTo(arr.get(middle).getBrand()) < 0)
				high = middle -1;
			else
				low = middle +1;
		}
		return  -1;
	}

	@Override
	public void addInstrument(ArrayList<E> arrIns,E musicalIns) 
	{
		arrIns.add(musicalIns);	
		setTotalPrice(); 
		setIsSorted(false);
	}

	@Override
	public boolean removeInstrument(ArrayList<E> arrIns, E musicalIns)
	{ 
		return arrIns.remove(musicalIns);
	}


	@Override
	public boolean removeAll(ArrayList<E> arr) 
	{
		if(arr.removeAll(arr)) 
		{
			setIsSorted(false);
			setTotalPrice();
			return true;
		}
		return false;
	}

	@Override
	public String toString() 
	{
		String str="\n-------------------------------------------------------------------------\n"
				+ "AFEKA MUSICAL INSTRUMENTS INVENTORY\n"
				+ "-------------------------------------------------------------------------\n";
		if(arrIns.size()==0)
			str+="There Is No Instruments To Show\n"; 
		else
		{
			for(int i=0; i<arrIns.size(); i++)
				str+=arrIns.get(i)+"\n";
		}
		setTotalPrice();
		return str+String.format("\nTotal Price:%1.2f \tSorted:\t%-9b ",totalPrice,isSorted);
	}
}
