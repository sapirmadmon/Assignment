//Sapir Madmon  ID:209010230

import java.util.ArrayList;

public interface InventoryManageable <E extends MusicalInstrument> //Inventory management interface
{
	void addAllStringInstruments(ArrayList<? extends MusicalInstrument> src, ArrayList<? super MusicalInstrument> to);

	void addAllWindInstruments(ArrayList<? extends MusicalInstrument> src, ArrayList<? super MusicalInstrument> to);

	void sortByBrandAndPrice(ArrayList<E> arr);

	int binnarySearchByBrandAndPrice(ArrayList<E> arr, String companyName,Number price);

	void addInstrument(ArrayList<E> arrIns,E musicalIns);

	boolean removeInstrument(ArrayList<E> arrIns, E musicalIns);

	boolean removeAll(ArrayList<E> arr); 
}
