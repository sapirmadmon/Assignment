//Sapir Madmon  ID:209010230

public interface InstrumentFunc extends Cloneable, Comparable<MusicalInstrument>
{

}
