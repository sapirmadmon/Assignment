#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "City.h"
#include "Kindergarten.h"
#include "General.h"
#include <stdarg.h>

void readCity(City* pCity, int typeFile)
{
	if (pCity->pGardenList != NULL)
	{
		releaseCity(pCity);
		pCity->count = 0;
	}

	// deciding which file to read according to MACRO fileName
	pCity->pGardenList = readAllGardensFromFile(FILE_NAME(typeFile), &pCity->count,typeFile);
	if (pCity->pGardenList == NULL)
		printf("Error reading city information\n");
}

void	showCityGardens(City* pCity)
{
	showAllGardens(pCity->pGardenList, pCity->count);

	if(pCity->count >= 3)
	{
		variadicFunc(pCity->pGardenList[0]->name,pCity->pGardenList[0]->childCount,
				pCity->pGardenList[1]->name,pCity->pGardenList[1]->childCount,
				pCity->pGardenList[2]->name,pCity->pGardenList[2]->childCount,NULL);
	}
}

void	showSpecificGardenInCity(City* pCity)
{
	showGardenMenu(pCity->pGardenList, pCity->count);
}

void saveCity(City* pCity,int typeFile)
{
	writeGardensToFile(pCity->pGardenList, pCity->count, FILE_NAME(typeFile),typeFile);
}

void cityAddGarden(City* pCity)
{
	pCity->pGardenList = addGarden(pCity->pGardenList, &pCity->count);
	if (pCity->pGardenList == NULL)//Allocation error
		printf("Error adding kindergarten\n");
}

void addChildToSpecificGardenInCity(City* pCity)
{
	addChildToGarden(pCity->pGardenList, pCity->count);
}

void birthdayToChild(City* pCity)
{
	handleBirthdayToChild(pCity->pGardenList, pCity->count);
}

int	countChova(City* pCity)
{
	int i;
	int count = 0;
	for (i = 0; i < pCity->count; i++)
	{
		if (pCity->pGardenList[i]->type == Chova)
			count += pCity->pGardenList[i]->childCount;
	}
	return count;
}

void releaseCity(City* pCity)
{
	release(pCity->pGardenList, pCity->count);
}

int compareGardenByName(const void* name1, const void* name2)
{
	const Garden* pG1 = *(const Garden**)name1;
	const Garden* pG2 = *(const Garden**)name2;
	return strcmp(pG1->name, pG2->name);
}

void sortGarden(City* pCity)
{
	insertionSort(pCity->pGardenList,pCity->count,sizeof(Garden*), compareGardenByName);
}

void sortChildrenInGarden(City* pCity)
{
	char sTemp[100];
	printf("Give me the Kindergarten Name:\n");
	scanf("%s",sTemp);
	Garden* garden=findGardenByName(pCity->pGardenList, pCity->count, sTemp);
	if (garden != NULL)
		sortChildren(garden);
	else
		printf("no such Kindergarten\n");
}

void sortGardenBy2Sort(City* pCity)
{
	insertionSort(pCity->pGardenList,pCity->count,sizeof(Garden*), compareGardenByTypeAndNumChildren);
}

int compareGardenByTypeAndNumChildren(const void* garden1, const void* garden2)
{
	int result;
	const Garden* pG1 = *(const Garden**)garden1;
	const Garden* pG2 = *(const Garden**)garden2;
	result=(pG1->type - pG2->type);
	if(result == 0)
		return pG1->childCount - pG2->childCount;
	else return result;
}

void variadicFunc(void* Namegarden, ...)
{
	va_list params;
	char*   currentName;
	int     currentCount;

	va_start(params, Namegarden);
	currentName = (char*)Namegarden;
	while (currentName != NULL)
	{
		currentCount = va_arg(params, int);
		printf("%-10s ----> %d\n", currentName, currentCount);
		currentName = va_arg(params, char*);
	}
	va_end(params);
}

List* createLinkedListForKindergartenType(City* pCity,GardenType  type)
{
	int i;
	List* list = (List*)malloc(sizeof(List));
	Node* newN;

	if(!initList(list))
	{
		printf("Failed to initialize list");
		return NULL;
	}

	newN = &list->head;
	for (i = 0; i < pCity->count; i++)
	{
		if(pCity->pGardenList[i]->type == type)
			newN = insertList(newN,pCity->pGardenList[i]);
	}
	return list;
}

int initList (List* pList)
{
	if (pList == NULL)
		return 0;

	pList->head.next = NULL;
	return 1;
}

Node* insertList(Node* pNode, Garden* key) //pNode: pointer to node BEFORE the place for the new one
{
	Node* newN;
	if (pNode == NULL)
		return NULL;
	newN = (Node*)malloc(sizeof(Node));
	if(!newN)
		return NULL;

	newN->key = key;
	newN->next = pNode->next;
	pNode->next = newN;

	return newN;
}

void displayKindergartensFroList(List* list)
{
	Node* newN = list->head.next; //the first node in list
	printf("Kindergartens list:\n");

	while(newN != NULL)
	{
		showGarden(newN->key);
		printf("\n");
		newN = newN->next;
	}
}

void kindergartensLinkedList(City* pCity)
{
	int typeGarden;
	List* list;

	do
	{
		printf("Garden type: \nEnter 0 for Chova \nEnter 1 for Trom Chova \nEnter 2 for Trom Trom Chova\n");
		scanf("%d",&typeGarden);
	}while(typeGarden < 0 || typeGarden > 2);

	list = createLinkedListForKindergartenType(pCity,((GardenType)typeGarden));
	displayKindergartensFroList(list);
	free(list);
}
