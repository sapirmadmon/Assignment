#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Child.h"
#include "General.h"


/**************************************************/
/*             Read a Child from a file           */
/**************************************************/
void readChild(FILE* fp, Child* pChild,int typeFile)
{
	if(typeFile == 0)
	{
		fscanf(fp, "%d", &pChild->id);
		fscanf(fp, "%d", &pChild->age);
	}
	else
	{
		unsigned char byte1,byte2;

		fread(&byte1,sizeof(unsigned char),1,fp);
		fread(&byte2,sizeof(unsigned char),1,fp);

		// decoding byte with bitwise operation on masked byte
		pChild->id = byte1 | ((byte2 & createMask(4,0)) << 8);
		pChild->age = (byte2 & createMask(7,5)) >> 5;
	}

}

/**************************************************/
/*            show a Child				           */
/**************************************************/
void showChild(const Child* pChild)
{
	printf("\nID:%d  ", pChild->id);
	printf("Age:%d  ", pChild->age);
}


/**************************************************/
void getChildFromUser(Child* pChild, int id)
/**************************************************/
/**************************************************/
{
	pChild->id = id;

	puts("\nAge:\t");
	scanf("%d", &pChild->age);
}


/**************************************************/
/*Write a Child to the open file				*/
/**************************************************/
void writeChild(FILE* fp,const Child* pChild,int typeFile)
{
	if(typeFile == 0)
	{
		fprintf(fp,"%d %d\n",pChild->id, pChild->age);
	}
	else
	{
		unsigned char byte1 = 0;
		unsigned char byte2 = 0;

		byte1 = (unsigned char)(pChild->id);
		byte2 = ( (createMask(4,0)) & (pChild->id >> 8) ) | (pChild->age << 5);

		fwrite(&byte1,sizeof(unsigned char),1,fp);
		fwrite(&byte2,sizeof(unsigned char),1,fp);
	}
}


int	findChildById(Child** pChildList, int count, int id)
{
	Child** pFound;
	int index;
	Child temp={id,0};
	Child* pTemp = &temp;

	qsort(pChildList, count, sizeof(Child*), compareChildById);
	pFound = (Child**)bsearch(&pTemp, pChildList, count, sizeof(Child*), compareChildById);

	if (pFound)
	{
		index = (pFound - pChildList) / sizeof(Child*);
		return index;
	}
	else
		return -1;
}

void birthday(Child* pChild)
{
	pChild->age++;
}

//void	releaseChild(Child* pChild)
//{
//	//nothing to release
//}


int compareChildById(const void* id1, const void* id2)
{
	const Child* pC1 = *(const Child**)id1;
	const Child* pC2 = *(const Child**)id2;
	return pC1->id - pC2->id;
}
