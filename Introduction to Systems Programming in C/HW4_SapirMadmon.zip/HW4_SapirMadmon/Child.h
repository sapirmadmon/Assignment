#ifndef __CHILD__
#define __CHILD__


typedef struct
{
	int	 id;
	int  age;
}Child;


void	readChild(FILE* fp, Child* pChild,int typeFile);
void	getChildFromUser(Child* pChild, int id);
void	showChild(const Child* pChild);
void    writeChild(FILE* fp,const Child* pChild,int typeFile);
int		findChildById(Child** pChildList, int count, int id);
void	birthday(Child* pChild);
//void	releaseChild(Child* pChild);

int     compareChildById(const void* id1, const void* id2);
#endif
