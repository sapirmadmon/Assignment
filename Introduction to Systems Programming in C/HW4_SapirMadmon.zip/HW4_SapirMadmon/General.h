#ifndef __PROTOTYPE__
#define __PROTOTYPE__

typedef enum
{
	EXIT,
	READ_CITY,
	SHOW_CITY,
	SHOW_GARDEN,
	WRITE_CITY,
	ADD_GARDEN,
	ADD_CHILD,
	CHILD_BIRTHDAY,
	COUNT_GRADUATE,
	SORT_GARDEN_BY_NAME,
	SORT_GARDEN_BY_TYPE_AND_NUM_CHILDREN,
	SORT_CHILDREN,
	GARDEN_LINKED_LIST,
	NofOptions
} MenuOptions;


int		menu();
char*	getStrExactLength(char* inpStr);
int		checkAllocation(const void* p);

void insertionSort(void* arr, int size,int sizetype, int(*compare)(const void* st1, const void* st2));

unsigned char createMask(int high, int low);

#endif
