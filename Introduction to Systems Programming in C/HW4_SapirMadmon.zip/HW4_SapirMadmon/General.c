#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "General.h"


const char* optionStr[NofOptions] =
{
		"Exit","Read City information from file",
		"Show all Kindergartens","Show a specific Kindergarten",
		"Save City information to file","Add a Kindergarten",
		"Add a Child","Birthday to a Child",
		"Count Hova childres","Sort Kindergartens by name",
		"Sort Kindergartens by type and children numbers",
		"Sort children in a Kindergarten","Kindergartens in Linked list"
};

/**************************************************/
int menu()
/**************************************************/
/**************************************************/
{
	int option,i;

	printf("\n==========================");
	printf("\nSelect:\n");
	for(i = 0 ; i < NofOptions; i++)
		printf("\n\t%d. %s.",i, optionStr[i]);
	printf("\n");
	scanf("%d", &option);
	return option;
}

char* getStrExactLength(char* inpStr)
{
	char* theStr = NULL;
	size_t len;

	len = strlen(inpStr) + 1;
	//allocate a place for the string in the right location in the array 
	theStr = (char*)malloc(len*sizeof(char));
	//Copy the string to the right location in the array 
	if (theStr != NULL)
		strcpy(theStr, inpStr);

	return theStr;
}

int checkAllocation(const void* p)
{
	if (!p)
	{
		printf("ERROR! Not enough memory!");
		return 0;
	}
	return 1;
}


void insertionSort(void* arr, int size,int sizetype, int(*compare)(const void* st1, const void* st2))
{
	int i,j;
	void* key;
	for (i = 0; i < size; i++)
	{
		key=(char*)malloc(sizetype);
		memcpy(key, (char*)arr+(i*sizetype),sizetype);
		for (j = i-1; j>=0 && compare(((char*)arr+(j*sizetype)), key) > 0; j--)
			memcpy((char*)arr+(j + 1)*sizetype,(char*)arr+(j*sizetype),sizetype);
		memcpy((char*)arr+(j+1)*sizetype,key,sizetype);
	}
	free(key);
}

// This function receives higher and lower bounds of  bit indexes (including)
//and creates a mask with 1 in this range, and 0 in all other places.
unsigned char createMask(int high, int low)
{
	return (1 << (high + 1)) - (1 << low);
}

