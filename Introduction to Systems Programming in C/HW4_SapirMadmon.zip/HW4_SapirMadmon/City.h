#ifndef __CITY__
#define __CITY__

#include "Kindergarten.h"

#define FILE_NAME(f) (f == 0) ? "DataFile.txt":"DataFile.bin"
#define DATA_FILE "DataFile.txt"

typedef struct
{
	Garden** pGardenList;
	int count;
}City;

// Node
typedef struct node
{
	Garden*		 key;
	struct node* next;
}Node;

// List
typedef struct
{
	Node head;
}List;

void readCity(City* pCity, int typeFile);
void showCityGardens(City* pCity);
void showSpecificGardenInCity(City* pCity);
void saveCity(City* pCity,int typeFile);
void cityAddGarden(City* pCity);
void addChildToSpecificGardenInCity(City* pCity);
void birthdayToChild(City* pCity);
int	countChova(City* pCity);
void releaseCity(City* pCity);


int compareGardenByName(const void* name1, const void* name2);
void sortGarden(City* pCity);
int compareGardenByTypeAndNumChildren(const void* garden1, const void* garden2);
void sortChildrenInGarden(City* pCity);
void sortGardenBy2Sort(City* pCity);
void variadicFunc(void* gardenName, ...);

List* createLinkedListForKindergartenType(City* pCity,GardenType  type);
int initList (List* pList);
Node* insertList(Node* pNode, Garden* key);
void displayKindergartensFroList(List* list);
void kindergartensLinkedList(City* pCity);

#endif
