/*
 * strFunctions.h
 *
 *  Created on: Nov 26, 2018
 *      Author: sapir
 */

#ifndef STRFUNCTIONS_H_
#define STRFUNCTIONS_H_

#define  MAX_LEN 100

void initString (char* str, int size);
void printString(char* str);
int countWords(char* str);
void longestInCaptital(char* str);
void revertWords(char* str);
int isPalindrome(const char* str);
void eraseCharsFromString(char* str, const char* subStr);

#endif /* STRFUNCTIONS_H_ */
