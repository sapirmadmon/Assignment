/*
 * strFunctions.c
 *
 *  Created on: Nov 26, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "strFunctions.h"

void initString (char* str, int size)
{
	getchar();
	fgets(str, size ,stdin);
	str[strcspn(str,"\n")]= '\0';

}

void printString(char* str)
{
	puts(str);
}

int countWords(char* str)
{
	int countWord=0;
	char tmp[MAX_LEN];
	strcpy(tmp,str);
	char* del=" ,:?-";
	char* words=strtok(tmp,del);

	while(words != NULL)
	{
		countWord++;
		words=strtok(NULL,del);
	}
	return countWord;
}

void longestInCaptital(char* str)
{
	int i, letters, maxLong = 0, maxLong_pos = 0;

	for (i = 0; str[i] != '\0'; i++) {
		for (letters = 0; str[i] != '\0' && str[i] != ' '; i++) {
			letters++; //count number of word
		}
		if (letters > maxLong) {
			maxLong = letters;
			maxLong_pos = i - maxLong;
		}
	}

	for(i=0; i<maxLong; i++)
		*(str+maxLong_pos+i)=toupper(*(str+maxLong_pos+i));
}

void revertWords(char* str)
{
	char temp;
	int i,j,k,lenStr;
	lenStr=strlen(str);

	for(i=0, j=0; j<lenStr; j++)
	{

		if(!isalnum(str[j]) || (j == lenStr-1) )
		{
			if(j<lenStr-1)
				k=j-1;
			else
				k=j;

			while(i<k)
			{
				temp=str[i];
				str[i]=str[k];
				str[k]=temp;
				i++;
				k--;
			}
			i=j+1;
		}
	}
	i=0;
	while(str[i] != '\0')
	{
		if(str[i] == ':' || str[i] == '?' || str[i] == '-' || str[i] == ' '  || str[i] == ',')
			str[i]='*';
		i++;
	}
}

void eraseCharsFromString(char* str, const char* subStr)
{
	char* dest=str;
	for(char* src = str; *src!='\0'; ++src)
	{
		if(strchr(subStr,*src)==NULL)
			*dest++=*src;
	}
	*dest='\0';
}

int isPalindrome(const char* str)
{
	char temp[MAX_LEN];
	strcpy(temp,str);
	char *pSrc,*pDes;
	const char* pStart=temp;
	const char* pEnd=temp;

	for(pSrc=pDes=temp; *pSrc != '\0'; pSrc++)
	{
		*pDes=*pSrc;
		if((*pDes >=  'a' && *pDes<= 'z') || (*pDes >= 'A' && *pDes <= 'Z'))
			pDes++;
	}
	*pDes='\0';

	while(*pEnd)
		pEnd++;
	--pEnd;

	while(pStart < pEnd)
	{
		if(toupper(*pStart) != toupper(*pEnd))
			return 0; //false
		--pEnd;
		++pStart;
	}
	return 1; //true
}
