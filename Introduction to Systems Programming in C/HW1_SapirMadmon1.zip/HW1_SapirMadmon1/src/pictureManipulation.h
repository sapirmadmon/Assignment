/*
 * pictureManipulation.h
 *
 *  Created on: Nov 12, 2018
 *      Author: sapir
 */

#ifndef PICTUREMANIPULATION_H_
#define PICTUREMANIPULATION_H_

#define SIZE 3
#define MAX 99
#define MIN 0

void menuEX1();
void randomMatrix(int* mat, int r, int c);
void degreeClockWise (int* matrix, int len);
void degreeCounterClockwise (int* matrix, int len);
void FlipVertical(int *mat,int len);
void transpose(int* mat,int len);
void FlipHorizontal(int* mat,int len);

#endif /* PICTUREMANIPULATION_H_ */
