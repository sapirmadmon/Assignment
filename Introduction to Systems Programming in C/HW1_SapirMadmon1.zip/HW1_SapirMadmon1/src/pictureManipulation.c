/*
 * pictureManipulation.c
 *
 *  Created on: Nov 12, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include "pictureManipulation.h"
#include "helpMethod.h"
#include <time.h>

void menuEX1()
{
	srand(time(NULL));
	int matrix[SIZE][SIZE];

	randomMatrix((int*)matrix,SIZE,SIZE);
	printMatrix((int*)matrix,SIZE,SIZE);

	int stopMenu = 0;
	int choice;
	do
	{
		printf("\nPlease choose one of the following options \n"
				"1 - 90 degree clockwise \n2 - 90 degree counter clockwise \n"
				"3 - Flip Horizontal \n4 - Flip Vertical \n-1 - Quit\n");

		scanf(" %d", &choice);

		switch (choice)
		{
		case 1:
			degreeClockWise ((int*)matrix,SIZE);
			break;
		case 2:
			degreeCounterClockwise ((int*)matrix,SIZE);
			break;
		case 3:
			FlipHorizontal((int*)matrix,SIZE);
			break;
		case 4:
			FlipVertical((int*)matrix,SIZE);
			break;
		case -1:
			stopMenu=1;
			break;
		default:
			printf("invalid input! Please enter your choice again\n");
			break;
		}
	} while (!stopMenu);
}

//--------------------------------------------------------

void randomMatrix(int* mat, int r, int c)
{
	int i,j;
	printf("\n");
	for(i=0;i<r;i++)
		for(j=0;j<c;j++,mat++)
			*mat=MIN + (rand()%(MAX-MIN+1));
}

//--------------------------------------------------------

void degreeClockWise (int* matrix, int len)
{
	transpose((int*)matrix,len);
	FlipVertical((int*)matrix,len);
}

//--------------------------------------------------------

void degreeCounterClockwise (int* matrix, int len)
{
	transpose((int*)matrix,len);
	FlipHorizontal((int*)matrix,len);

}

//--------------------------------------------------------

void FlipVertical(int* mat,int len)
{
	int i,j;
	for(i=0; i<len; i++)
	{
		for(j=0; j<len/2; j++)
		{
			swap((int*)(mat+ i * len + j),(int*)(mat + i * len + (len-j-1)));
		}
	}
	printf("--------- picture after manipulation ---------\n");
	printMatrix((int*)mat,len,len);
}

//--------------------------------------------------------

void transpose(int* mat,int len)
{
	int i,j;
	for(i=0; i<len; i++)
	{
		for(j=i+1; j<len; j++)
		{
			swap((mat+i*len+j),(mat+j*len+i));
		}
	}
}

//--------------------------------------------------------

void FlipHorizontal (int* mat,int len)
{
	int i,j;
	for(i=0; i<len/2; i++)
	{
		for(j=0; j<len; j++)
		{
			swap((int*)(mat+ i * len + j),(int*)(mat + (len-i-1) * len + j));
		}
	}
	printf("--------- picture after manipulation ---------\n");
	printMatrix((int*)mat,len,len);
}
