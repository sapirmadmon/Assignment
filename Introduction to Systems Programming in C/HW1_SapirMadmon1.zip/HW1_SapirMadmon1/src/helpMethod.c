/*
 * helpMethod.c
 *
 *  Created on: Nov 12, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include "helpMethod.h"

void printMatrix(const int* mat, int r, int c)
{
	int i,j;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++,mat++)
			printf("%5d",*mat);
		printf("\n");
	}
}

//--------------------------------------------------------

void swap(int* a, int* b)
{
	int temp = *b;
	*b = *a;
	*a = temp;
}
