/*
 * NumberGame .c
 *
 *  Created on: Nov 14, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include "NumberGame .h"
#include "helpMethod.h"
#include <time.h>

void menuEX2()
{
	srand(time(NULL));
	int matrix[M][N];

	insertMat((int*)matrix,M,N);
	randomSwap((int*)matrix,M,N);
	printMatrix((int*)matrix,M,N);

	printf("\n");
	game((int*)matrix,M,N);
}

//------------------------------------------------

void insertMat(int* mat,int r, int c)
{
	int counter=0;
	int i,j;
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			*(mat+ i* c + j)=counter;
			counter++;
		}
	}
}

//------------------------------------------------

void randomSwap(int* mat,int r, int c)
{
	int i,rand1,rand2,rand3,rand4;
	for(i=0; i<=SHUFFLE_COUNT; i++)
	{
		rand1= (rand()%r);
		rand2= (rand()%c);
		rand3= (rand()%r);
		rand4= (rand()%c);

		swap((int*)(mat+ rand2 * c + rand1),(int*)(mat + rand4 * c + rand3));
	}
}

//------------------------------------------------

int checkIfFinish(int* mat,int r, int c)
{
	int i,j;
	int count=0;
	int endLoop=0;
	for(i = 0; i < r && !endLoop; i++)
	{
		for(j = 0; j < c && !endLoop; j++)
		{
			if(*(mat + i * c + j) != count)
				endLoop=1;
			else
				count++;
		}
	}
	return count;
}

//------------------------------------------------

void SearchNum(int* mat,int* row,int* col ,int num,int r, int c) //Method to get row and column of number
{
	int exist=0;
	int i,j;
	for (i = 0; i < r && !exist; i++)
	{
		for (j = 0; j < c && !exist; j++)
		{
			if(*(mat+ i* c + j) == num)
			{
				*row = i;
				*col  = j;
				exist = 1;
			}
		}
	}
}

//------------------------------------------------

int isStepLegal(int* mat,int r, int c, int stepIndex)
{
	int row0,col0; //The indexes of the zero cell
	SearchNum(mat, &row0, &col0, 0, r, c); //find the indexes of the zero cell

	//checking move up
	if((row0 - 1 >= 0) && (*(mat + (row0-1)*c +col0) == stepIndex))
		return 1;

	//checking move down
	else if((row0 + 1 < r) && (*(mat + (row0+1)*c +col0) == stepIndex))
		return 1;

	//checking move right
	else if((col0 + 1 < c) && (*(mat + row0 *c +(col0+1)) == stepIndex))
		return 1;

	//checking move left
	else if((col0 - 1 >= 0) && (*(mat + row0 *c +(col0-1)) == stepIndex))
		return 1;

	else return 0;
}

//------------------------------------------------

void game(int* mat,int r, int c)
{
	int checkIfWin = 0;
	int checkUserStep = 0;
	int userStep, row0, col0, stepRow, stepCol;

	do
	{
		if (checkIfFinish((int*)mat, r, c) == (r*c))
		{
			printf("You win! The game is over!\n");
			checkIfWin = 1;
		}
		else
		{
			checkUserStep = 0;
			while (!checkUserStep)
			{
				printf("\nYour step: ");
				scanf("%d", &userStep);
				if (userStep < 0 || userStep >= (c*r) || (!(isStepLegal((int*)mat, r, c, userStep))))
					printf("\nInvalid step!");
				else
					checkUserStep = 1;
			}

			SearchNum((int*)mat, &row0, &col0, 0, r, c); //find index zero
			SearchNum((int*)mat, &stepRow, &stepCol, userStep,r,c); //find index step of user

			swap((((int*)mat) + row0 * c + col0), (((int* )mat) + stepRow * c + stepCol)); //Swap between them

			printMatrix((int*)mat,r,c);
		}
	} while (!checkIfWin);
}
