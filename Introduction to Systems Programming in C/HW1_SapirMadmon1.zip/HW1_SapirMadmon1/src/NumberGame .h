/*
 * NumberGame .h
 *
 *  Created on: Nov 14, 2018
 *      Author: sapir
 */

#ifndef NUMBERGAME__H_
#define NUMBERGAME__H_

#define N 3 //column
#define M 3 //row
#define SHUFFLE_COUNT 30

void menuEX2();
void insertMat(int* mat,int r, int c);
void randomSwap(int* mat,int r, int c);
int checkIfFinish(int* mat,int r, int c);
void SearchNum(int* mat,int* row,int* col ,int num, int r, int c);
int isStepLegal(int* mat,int r, int c, int stepIndex);
void game(int* mat,int r, int c);


#endif /* NUMBERGAME__H_ */
