/*
 * helpMethod.h
 *
 *  Created on: Nov 12, 2018
 *      Author: sapir
 */

#ifndef HELPMETHOD_H_
#define HELPMETHOD_H_

void printMatrix(const int* mat, int r, int c);
void swap(int* a, int* b);

#endif /* HELPMETHOD_H_ */
