/*
 * menu.c
 *
 *  Created on: Nov 12, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include <ctype.h>
#include "pictureManipulation.h"
#include "NumberGame .h"

int main(void) {

	int stopMenu = 0;
	char choice;
	do
	{
		printf("Please choose one of the following options \n P/p - picture Manipulation \n "
				"N/n - Number Game \n E/e - Quit \n");
		scanf(" %c", &choice);

		choice=tolower(choice);

		switch (choice)
		{
		case 'p':
			menuEX1();
			break;
		case 'n':
			menuEX2();
			break;
		case 'e':
			printf("Bye Bye");
			stopMenu=1;
			break;
		default:
			printf("invalid input! Please enter your choice again\n\n");
			break;
		}
	} while (!stopMenu);
}
