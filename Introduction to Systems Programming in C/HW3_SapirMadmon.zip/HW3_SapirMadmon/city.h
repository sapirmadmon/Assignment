/*
 * city.h
 *
 *  Created on: Dec 13, 2018
 *      Author: sapir
 */

#ifndef CITY_H_
#define CITY_H_

#include "kindergarten.h"

typedef struct
{
	Kindergarten** KindergartenArr;
	int numKindergarten;
}City;

void ReleaseCity(City* pCity);

void readCity(City* city);
void showCityGardens(const City* city);
void showSpecificGardenInCity(const City* city);
void saveCity(City* city);
void addChildToSpecificGardenInCity(City* city);
void cityAddGarden(City* city);
void birthdayToChild (City* city);
int countChova(City* city);

//help method
int CheckExistsGarden(City* city,const char* name);
Kindergarten* FindSpecificGarden (City* city, char* nameGarden);

#endif /* CITY_H_ */
