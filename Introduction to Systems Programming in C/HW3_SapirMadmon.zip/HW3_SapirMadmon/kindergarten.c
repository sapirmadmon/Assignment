/*
 * kindergarten.c
 *
 *  Created on: Dec 11, 2018
 *      Author: sapir
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kindergarten.h"


const char* TypeTiltels[NumOfTypes]={"Chova","Trom Chova","Trom Trom Chova"};

void initKindergarten(Kindergarten* pKindergarten,char* nameGarden)
{
	int i;
	pKindergarten->name=(char*)malloc(sizeof(char));
	strcpy(pKindergarten->name,nameGarden);
	pKindergarten->type=getTypeFromUser();
	printf("Enter children Details:\n\n");
	printf("Children count:\n");
	scanf("%d", &pKindergarten->numChildren);

	pKindergarten->ChildArr=(Child**)malloc(pKindergarten->numChildren*sizeof(Child*));

	if(!pKindergarten->ChildArr)
		return;

	for(i=0; i<pKindergarten->numChildren; i++)
	{
		pKindergarten->ChildArr[i]=(Child*)malloc(1*sizeof(Child));

		if(!pKindergarten->ChildArr[i])
			return;

		initChild(pKindergarten->ChildArr[i]);
	}

}

void printKindergarten(const Kindergarten* pKindergarten)
{
	int i;
	printf("Name: %s   Type: %s   Children:%d\n",pKindergarten->name,pKindergarten->type[TypeTiltels],pKindergarten->numChildren);

	for(i=0; i<pKindergarten->numChildren; i++)
		printChild(pKindergarten->ChildArr[i]);
}

void releaseKindergarten(Kindergarten* pKindergarten)
{
	int i;
	free(pKindergarten->name);

	for(i=0; i<pKindergarten->numChildren; i++)
	{
		free(pKindergarten->ChildArr[i]);
	}
	free(pKindergarten->ChildArr);
}

char* getDyanmicStrName(const char* msg)
{
	char* str;
	char temp[LEN];
	printf("Please enter name of kindergarten %s\n",msg);
	scanf("%s",temp);
	str=strdup(temp);
	return str;
}

PreschoolType getTypeFromUser()
{
	int i,t;
	printf("Garden type:\n");

	do{
		for(i=0; i<NumOfTypes; i++)
			printf("Enter %d for %s\n",i,TypeTiltels[i]);
		scanf("%d",&t);
	}while(t<0 || t>=NumOfTypes);

	return (PreschoolType)t;
}

int readKindergartenFromFile(FILE* fp, Kindergarten* theGarden)
{
	int i,type;
	char temp[LEN];

	fscanf(fp,"%s %d %d",temp,&type,&theGarden->numChildren);
	theGarden->type = (PreschoolType)type;
	theGarden->name = strdup(temp);

	if(!theGarden->name)
		return 0;

	theGarden->ChildArr=(Child**)malloc(theGarden->numChildren*sizeof(Child*));
	if(!theGarden->ChildArr)
		return 0;

	for(i=0; i<theGarden->numChildren; i++)
	{
		theGarden->ChildArr[i]=(Child*)malloc(1*sizeof(Child));
		if(!theGarden->ChildArr[i])
			return 0;
		if(!readChildFromFile(fp,theGarden->ChildArr[i]))
			return 0;
	}
	return 1;
}


void writeKindergartenToFile(FILE* fp,const Kindergarten* theGarden)
{
	int i;
	fprintf(fp,"%s  %d %d\n", theGarden->name, theGarden->type, theGarden->numChildren);
	for (i = 0; i < theGarden->numChildren; i++)
		writeChildToFile(fp,theGarden->ChildArr[i]);
}

//help method
void addChildToGarden(Kindergarten* garden) //add Child to Garden with ID
{
	int id;
	do
	{
		printf("ID No.:\n");
		scanf("%d",&id);
	}while(CheckExistsChild(garden,id)==0);

	garden->ChildArr=(Child**)realloc(garden->ChildArr,(garden->numChildren+1)*sizeof(Child*));

	if(!garden->ChildArr)
		return;

	garden->ChildArr[garden->numChildren] = (Child*)malloc(1*sizeof(Child));

	if(!garden->ChildArr[garden->numChildren])
		return;

	initChildID(garden->ChildArr[garden->numChildren],id);

	garden->numChildren++;
}

//help method
int CheckExistsChild(Kindergarten* garden,int id)
{
	int i;
	for(i=0; i<garden->numChildren; i++)
	{
		if(garden->ChildArr[i]->id == id)
		{
			printf("This child is in the Kindergarten\n");
			return 0;
		}
	}
	return 1;
}

//help method
Child* FindSpecificChild (Kindergarten* garden, int idChild)
{
	int i;
	for(i=0; i<garden->numChildren; i++)
	{
		if(garden->ChildArr[i]->id == idChild)
			return (garden->ChildArr[i]);
	}
	return NULL;
}

