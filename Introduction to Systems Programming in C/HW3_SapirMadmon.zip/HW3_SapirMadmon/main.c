/*
 * main.c
 *
 *  Created on: Dec 10, 2018
 *      Author: sapir
 */
#include "kindergarten.h"
#include "child.h"
#include "city.h"
#include <stdio.h>

#define READ_CITY 1
#define SHOW_CITY 2
#define SHOW_GARDEN 3
#define WRITE_CITY 4
#define ADD_GARDEN 5
#define ADD_CHILD 6
#define CHILD_BIRTHDAY 7
#define COUNT_GRADUATE 8
#define EXIT 0

void menu()
{
	printf("\n\n");
	printf("========================== \nSelect: \n\n");
	printf("%d. Read City information from file.\n", READ_CITY);
	printf("%d. Show all Kindergartens.\n", SHOW_CITY);
	printf("%d. Show a specific Kindergarten.\n", SHOW_GARDEN);
	printf("%d. Save City information to file.\n", WRITE_CITY);
	printf("%d. Add a Kindergarten.\n", ADD_GARDEN);
	printf("%d. Add a Child.\n", ADD_CHILD);
	printf("%d. Birthday to a Child.\n", CHILD_BIRTHDAY);
	printf("%d. Count Hova childres.\n", COUNT_GRADUATE);
	printf("%d. Exit.\n", EXIT);
}

int main()
{
	City utz = {NULL,0};
	int uReq;

	//first time read
	readCity(&utz);
	do
	{
		menu();
		scanf("%d",&uReq);
		switch (uReq)
		{
		case  READ_CITY:
			readCity(&utz);
			break;

		case  SHOW_CITY:
			showCityGardens(&utz);
			break;

		case  SHOW_GARDEN:
			showSpecificGardenInCity(&utz);
			break;

		case  WRITE_CITY:
			saveCity(&utz);
			break;

		case  ADD_GARDEN:
			cityAddGarden(&utz);
			break;

		case  ADD_CHILD:
			addChildToSpecificGardenInCity(&utz);
			break;

		case  CHILD_BIRTHDAY:
			birthdayToChild(&utz);
			break;

		case COUNT_GRADUATE:
			printf("There are %d children going to school next year\n",countChova(&utz));
			break;

		}
	}while (uReq!=EXIT);

	ReleaseCity(&utz); //free all allocations

	return 1;
}


