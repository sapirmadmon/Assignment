/*
 * kindergarten.h
 *
 *  Created on: Dec 11, 2018
 *      Author: sapir
 */

#ifndef KINDERGARTEN_H_
#define KINDERGARTEN_H_

#include "child.h"
#define LEN 100

typedef enum {
	Chova,TromChova,TromTromChova,NumOfTypes
}PreschoolType;

const char* TypeTiltels[NumOfTypes];

typedef struct
{
	char* name;
	PreschoolType type;
	int numChildren;
	Child** ChildArr;
}Kindergarten;

void initKindergarten(Kindergarten* pKindergarten,char* nameGarden);
void printKindergarten(const Kindergarten* pKindergarten);
void releaseKindergarten(Kindergarten* pKindergarten);

char* getDyanmicStrName(const char* msg);
PreschoolType getTypeFromUser();

int readKindergartenFromFile(FILE* fp, Kindergarten* theGarden);
void writeKindergartenToFile(FILE* fp,const Kindergarten* theGarden);

//help method
int CheckExistsChild(Kindergarten* garden,int id);
void addChildToGarden(Kindergarten* garden);
Child* FindSpecificChild (Kindergarten* garden, int idChild);

#endif /* KINDERGARTEN_H_ */
