/*
 * child.h
 *
 *  Created on: Dec 11, 2018
 *      Author: sapir
 */

#ifndef CHILD_H_
#define CHILD_H_

#include <stdio.h>

typedef struct
{
	int id;
	int age;
}Child;

void initChild(Child* pChild);
void initChildID(Child* pChild, int idChild);
void printChild(const Child* pChild);

int readChildFromFile(FILE* fp, Child* theChild);
void writeChildToFile(FILE* fp, Child* theChild);

#endif /* CHILD_H_ */
