/*
 * city.c
 *
 *  Created on: Dec 13, 2018
 *      Author: sapir
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "city.h"

#define FILE_NAME "DataFile.txt"

void ReleaseCity(City* pCity)
{
	int i;
	for(i=0; i<pCity->numKindergarten; i++)
	{
		free(pCity->KindergartenArr[i]);
	}
	free(pCity->KindergartenArr);
}

void readCity(City* city)
{
	FILE* fp;
	int i;

	ReleaseCity(city);

	fp = fopen(FILE_NAME, "r");

	if (!fp)
		return;

	fscanf(fp, "%d\n", &(city->numKindergarten));

	city->KindergartenArr=(Kindergarten**)malloc((city->numKindergarten)*sizeof(Kindergarten*));

	if(!city->KindergartenArr)
	{
		fclose(fp);
		return;
	}
	for(i=0; i<city->numKindergarten; i++)
	{
		city->KindergartenArr[i]=(Kindergarten*)malloc(1*sizeof(Kindergarten));
		if(!city->KindergartenArr[i])
		{
			fclose(fp);
			return;
		}

		if(!readKindergartenFromFile(fp, city->KindergartenArr[i]))
		{
			fclose(fp);
			return;
		}
	}
	fclose(fp);
}

void showCityGardens(const City* city)
{
	int i;
	for(i=0; i<city->numKindergarten; i++)
	{
		printf("\nKindergarten %d:\n", (i+1));
		printKindergarten(city->KindergartenArr[i]);
	}
}

void showSpecificGardenInCity(const City* city)
{
	char temp[LEN];
	printf("Give me the Kindergarten Name:\n");
	scanf("%s",temp);
	int i;
	for(i=0; i<city->numKindergarten; i++)
	{
		if(strcmp(city->KindergartenArr[i]->name,temp)==0)
		{
			printKindergarten(city->KindergartenArr[i]);
			return;
		}
	}
	printf("No such Kindergarten");
}

void saveCity(City* city)
{
	FILE* fp;
	int i;

	fp=fopen(FILE_NAME,"w");
	if(!fp)
		return;

	fprintf(fp,"%d\n",city->numKindergarten);
	for(i=0; i<city->numKindergarten; i++)
	{
		writeKindergartenToFile(fp,city->KindergartenArr[i]);
	}
	fclose(fp);
}

void cityAddGarden(City* city)
{
	char name[LEN];
	do
	{
		printf("Name:\n");
		scanf("%s",name);
	}while(CheckExistsGarden(city,name)==0);

	city->KindergartenArr=(Kindergarten**)realloc(city->KindergartenArr,(city->numKindergarten+1)*sizeof(Kindergarten*));

	if(!city->KindergartenArr)
		return;

	city->KindergartenArr[city->numKindergarten] = (Kindergarten*)malloc(1*sizeof(Kindergarten));

	if(!city->KindergartenArr[city->numKindergarten])
		return;

	initKindergarten(city->KindergartenArr[city->numKindergarten],name);

	(city->numKindergarten)++;
}

void addChildToSpecificGardenInCity(City* city)
{
	int i;
	char name[LEN];
	printf("Give me the Kindergarten Name:\n");
	scanf("%s",name);
	for(i=0; i<city->numKindergarten; i++)
	{
		if(strcmp(city->KindergartenArr[i]->name,name)==0)
		{
			addChildToGarden(city->KindergartenArr[i]);
			return;
		}
	}
	printf("no such Kindergarten\n");
}

void birthdayToChild (City* city)
{
	char name[LEN];
	int id;
	printf("Give me the Kindergarten Name:\n");
	scanf("%s",name);
	Kindergarten* garden=FindSpecificGarden(city,name);
	if(garden != NULL)
	{
		printf("Enter child id\n");
		scanf("%d",&id);
		Child* child=FindSpecificChild(FindSpecificGarden(city,name),id);
		if(child != NULL)
		{
			child->age++;
			return;
		}
		else
		{
			printf("No such child");
			return;
		}
	}
	else
	{
		printf("No such Kindergarten");
		return;
	}
}

int countChova(City* city)
{
	int countChild=0, i,j;
	for(i=0; i<city->numKindergarten; i++)
	{
		if(city->KindergartenArr[i]->type == 0)
		{
			for(j=0; j<city->KindergartenArr[i]->numChildren; j++)
				countChild++;
		}
	}
	return countChild;
}

//help method
int CheckExistsGarden(City* city,const char* name)
{
	int i;
	for(i=0; i<city->numKindergarten; i++)
	{
		if(strcmp(city->KindergartenArr[i]->name,name)==0)
		{
			printf("This Kindergarten already in list\n");
			return 0;
		}
	}
	return 1;
}

//Help method
Kindergarten* FindSpecificGarden (City* city, char* nameGarden)
{
	int i;
	for(i=0; i<city->numKindergarten; i++)
	{
		if(strcmp((city->KindergartenArr[i]->name),nameGarden)==0)
			return (city->KindergartenArr[i]);
	}
	return NULL;
}
