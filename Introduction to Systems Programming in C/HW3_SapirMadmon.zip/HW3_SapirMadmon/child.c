/*
 * child.c
 *
 *  Created on: Dec 11, 2018
 *      Author: sapir
 */

#include <stdio.h>
#include "child.h"

void initChild(Child* pChild)
{
	printf("ID No.:\n");
	scanf("%d", &pChild->id);
	printf("\nAge:\n");
	scanf("%d", &pChild->age);
}

//help method
void initChildID(Child* pChild, int idChild)
{
	pChild->id=idChild;
	printf("Age:\n");
	scanf("%d",&pChild->age);
}

void printChild(const Child* pChild)
{
	printf("Id:%d  Age:%d\n",pChild->id, pChild->age);
}

int readChildFromFile(FILE* fp, Child* theChild)
{
	fscanf(fp,"%d %d\n", &theChild->id, &theChild->age);
	return 1;
}

void writeChildToFile(FILE* fp, Child* theChild)
{
	fprintf(fp,"%d %d\n",theChild->id, theChild->age);
}
