# sapir madmon. ID: 209010230
# Roman Prasolov. ID: 313091746

import tkinter as tk
from datetime import datetime
from tkinter import *


def dec(func):
    def wrapper(*args, **kwargs):
        if func(*args, **kwargs) is True:
            #result = func(*args, **kwargs)
            dateLabel.config(text=str(datetime.now()))
            #return result
        else:
            dateLabel.config(text="")
    return wrapper


class Account:

    def __init__(self, client_name, num_account, balance, frame_card=1500):
        self.client_name = client_name
        self.num_account = num_account
        self.balance = balance
        self.frame_card = frame_card

    def deposit_account(self, money):
        self.balance += money

    def pull_account(self, money):
        if self.balance >= money and money <= self.frame_card:
            self.balance -= money
            return True
        return False

    def receipt_balance(self):
        print(f"the current balance is {self.balance}")


class Bank:

    def __init__(self):
        self.ls_account = []

    def add_account(self, account):
        for i in self.ls_account:
            if i.num_account is account.num_account:
                return False
        self.ls_account.append(account)
        return True

    @dec
    def deposit(self):
        if entryMyAccount.get() is "":
            errorLabel.config(text="please insert account")
            return False
        if entryMoney.get() is "":
            errorLabel.config(text="please insert money to deposit")
            return False
        numAccount = int(entryMyAccount.get())
        money = int(entryMoney.get())
        for i in self.ls_account:
            if i.num_account == numAccount:
                i.deposit_account(money)
                errorLabel.config(text="")
                return True
        errorLabel.config(text="Error")
        return False

    @dec
    def balance(self):
        if entryMyAccount.get() is "":
            errorLabel.config(text="please insert your account number")
            return False
        numAccount = int(entryMyAccount.get())
        for i in self.ls_account:
            if i.num_account == numAccount:
                balance1.config(text=str(i.balance))
                nameCustomer1.config(text=i.client_name)
                numberAccount1.config(text=str(i.num_account))
                LineOfCredit1.config(text=i.frame_card)
                errorLabel.config(text="")
                return True
        errorLabel.config(text="Error")
        return False

    @dec
    def pull(self):
        if entryMyAccount.get() is "":
            errorLabel.config(text="please insert account")
            return False
        if entryMoney.get() is "":
            errorLabel.config(text="please insert money to pull")
            return False
        numAccount = int(entryMyAccount.get())
        money = int(entryMoney.get())
        for i in self.ls_account:
            if i.num_account == numAccount:
                if i.pull_account(money) is True:
                    errorLabel.config(text="")
                    return True
        errorLabel.config(text="Error")
        return False

    @dec
    def transfer_money(self):
        if entryMyAccount.get() is "":
            errorLabel.config(text="please insert your account")
            return False
        if entryMoney.get() is "":
            errorLabel.config(text="please insert money to transfer")
            return False
        if entryOtherAccount.get() is "":
            errorLabel.config(text="please insert number account of other person")
            return False
        numAccount = int(entryMyAccount.get())
        money = int(entryMoney.get())
        numOtherAccount = int(entryOtherAccount.get())
        for i in self.ls_account:
            if i.num_account == numAccount:
                for j in self.ls_account:
                    if j.num_account == numOtherAccount:
                        if i.pull_account(money):
                            j.deposit_account(money)
                            errorLabel.config(text="")
                            return True
                        else:
                            errorLabel.config(text="can't transfer money")
                            return False
        errorLabel.config(text="Error")
        return False

    def generator(self):
        for account in self.ls_account:
            yield account.balance


if __name__ == '__main__':
    root = tk.Tk()
    Accounts = Bank()
    var = StringVar()
    # Frame
    frameButtons = Frame(root, bd=30)
    frameButtons.pack(side=BOTTOM)
    frameLabel = Frame(root, bd=30)
    frameLabel.pack(side=LEFT)
    frameGenerator = Frame(root, bd=30)
    frameGenerator.pack(side=RIGHT)
    frameAccount = Frame(root, bd=30)
    frameAccount.pack(side=TOP)

    # Labels of account details
    nameCustomer = Label(frameAccount, text="client name")
    nameCustomer.grid(row=0, column=0)
    numberAccount = Label(frameAccount, text="Number account")
    numberAccount.grid(row=0, column=2)
    balance = Label(frameAccount, text="Balance")
    balance.grid(row=0, column=4)
    LineOfCredit = Label(frameAccount, text="Line of credit")
    LineOfCredit.grid(row=0, column=6)
    # Entry
    nameCustomer1 = Label(frameAccount, text="")
    nameCustomer1.grid(row=1, column=0)
    numberAccount1 = Label(frameAccount, text="")
    numberAccount1.grid(row=1, column=2)
    balance1 = Label(frameAccount, text="")
    balance1.grid(row=1, column=4)
    LineOfCredit1 = Label(frameAccount, text="")
    LineOfCredit1.grid(row=1, column=6)
    dateLabel = Label(frameAccount, text="", fg="blue")
    dateLabel.grid(row=3, column=0)

    # Label
    label4 = Label(frameAccount, text="balance-generator:")
    label4.grid(row=6, column=0)
    errorLabel = Label(frameAccount, text="", fg="red")
    errorLabel.grid(row=3, column=0)

    label1 = Label(frameLabel, text="my account number")
    label1.grid(row=0, column=0)
    entryMyAccount = Entry(frameLabel, text="")
    entryMyAccount.grid(row=0, column=1)

    label2 = Label(frameLabel, text="money")
    label2.grid(row=1, column=0)
    entryMoney = Entry(frameLabel, text="")
    entryMoney.grid(row=1, column=1)

    label3 = Label(frameLabel, text="other account number")
    label3.grid(row=2, column=0)
    entryOtherAccount = Entry(frameLabel, text="")
    entryOtherAccount.grid(row=2, column=1)

    # Buttons
    depositButton = Button(frameButtons, text="deposit", command=Accounts.deposit)
    pullButton = Button(frameButtons, text="pull", command=Accounts.pull)
    receipt_balanceButton = Button(frameButtons, text="view Balance", command=Accounts.balance)
    transfer_moneyButton = Button(frameButtons, text="transfer money", command=Accounts.transfer_money)

    depositButton.grid(row=0, column=1)
    pullButton.grid(row=0, column=3)
    receipt_balanceButton.grid(row=0, column=5)
    transfer_moneyButton.grid(row=0, column=7)

    David = Account("david", 1, balance=1000)
    Sapir = Account("sapir", 2, balance=500)
    Dan = Account("dan", 3, balance=400)
    Elad = Account("elad", 4, balance=300)

    listAccount = [David, Sapir, Dan, Elad]
    for i in listAccount:
        Accounts.add_account(i)

    # ex_1c
    for balance in Accounts.generator():
        label = Label(text=balance)
        label.pack()

    root.mainloop()
