# sapir madmon. ID: 209010230
# Roman Prasolov. ID: 313091746
from tkinter import *


def print_words(letter, include):
    with open("word.txt", "r") as file:
        txt = file.read()
        lines = txt.split("\n")
        for line in lines:
            new_line = line.split(",")
            for word in new_line:
                if (letter.lower() in word or letter.upper() in word) and include:
                    yield word
                elif include is False and (letter.lower() not in word and letter.upper() not in word):
                    yield word


def choose_option(char, option, listbox):
    listbox.delete(0, END)
    for word in print_words(char, option):
        mylist.insert(END, str(word))


def restart(listbox, entry, R1, R2):
    listbox.delete(0, END)
    entry.delete(0, END)
    R1.deselect()
    R2.deselect()


def get_top_letters_from_file(NUM_OF_LETTERS=10):
    import string
    set_letters = set()
    dictionary = {}
    with open("word.txt", "r") as file:
        txt = file.read()
        lines = txt.split("\n")
        for line in lines:
            new_line = line.split(",")
            for word in new_line:
                for letter in word:
                    if letter in string.ascii_letters and len(set_letters) < NUM_OF_LETTERS:
                        set_letters.add(letter)
                    if letter in set_letters:
                        if letter in dictionary:
                            dictionary[letter] += 1
                        else:
                            dictionary[letter] = 1
    return set_letters, dictionary


def graph():
    set_letters, count_of_letters = get_top_letters_from_file(10)
    from matplotlib import pyplot as plt
    plt.plot(count_of_letters.keys(), count_of_letters.values())
    plt.show()


if __name__ == '__main__':

    graph()#exB
    # exA
    root = Tk()
    frameListBox = Frame(root, bd=30)
    frameListBox.pack(side=BOTTOM)
    frameSelect = Frame(root, bd=30)
    frameSelect.pack(side=TOP)

    scrollbar = Scrollbar(frameListBox)
    scrollbar.pack(side=RIGHT, fill=Y)

    restartButton = Button(frameSelect, text="restart", fg="red",
                           command=lambda: restart(mylist, entryChar, R1, R2))

    restartButton.grid(row=0, column=8)

    label1 = Label(frameSelect, text="choose char: ")
    label1.grid(row=0, column=0)
    entryChar = Entry(frameSelect, text="")
    entryChar.grid(row=0, column=1)

    var = BooleanVar()
    mylist = Listbox(frameListBox, yscrollcommand=scrollbar.set)

    # radio button
    R1 = Radiobutton(root, text="include", variable=var, value=0,
                     command=lambda: choose_option(entryChar.get(), True, mylist))
    R1.pack()
    R2 = Radiobutton(root, text="exclude", variable=var, value=1,
                     command=lambda: choose_option(entryChar.get(), False, mylist))
    R2.pack()

    mylist.pack(side=LEFT, fill=BOTH)
    scrollbar.config(command=mylist.yview)

    root.mainloop()
