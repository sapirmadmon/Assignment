import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.TreeSet;

class ListIterButton extends CommandButton {

	private LinkedHashMap<String, Address> m;
	private ListIterator<Address> lit;
	private int count;

	public ListIterButton(AddressBookPane pane, RandomAccessFile r) {
		super(pane, r);
		this.setText("Iter");
		this.count = 0;
		this.m = new LinkedHashMap<>();
	}

	@Override
	public void Execute() {
		this.count++;

		if (this.count == 1) {
			try {
				raf.seek(0);
				this.lit = new ListIter(0);
				// copy file to map without duplicated
				while (lit.hasNext()) {
					Address ad = lit.next();
					String key = ad.getName() + ad.getStreet() + ad.getCity() + ad.getState();
					m.put(key, ad);
				}

				((ListIter) lit).reset(); // Reset Iterator and clean file

				for (Address ad : m.values()) {
					lit.add(ad);
				}

				setAddress(readAddressInToAddress(0)); // Back to first address

			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				Comparator<Address> comp = new CompareAddressByStreet();
				TreeSet<Address> ts = new TreeSet<>(comp);
				for (Address ad : m.values()) {
					ts.add(ad);
				}

				((ListIter) lit).reset(); // Reset Iterator and clean file

				for (Address ad : ts) {
					lit.add(ad);
				}

				setAddress(readAddressInToAddress(0)); // Back to first address

			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/** class ListIter **/
	public class ListIter implements ListIterator<Address> {

		private int cur = 0; // Next worker to return
		private int last = -1; // Last worker that was returned

		private int recSize; // Record size
		private long numRec; // Number of records

		/** Constructor */
		ListIter(int index) throws FileNotFoundException, IOException {
			cur = index;
			this.recSize = RECORD_SIZE * 2;
			this.numRec = raf.length() / RECORD_SIZE / 2;
		}

		@Override
		public void add(Address ad) {
			if (cur < 0 || cur > recSize)
				throw new IndexOutOfBoundsException();

			ArrayList<Address> lst; // Help ArrayList
			try {
				lst = fileToArrayList();
				lst.add(cur, ad);
				arrayListToFile(lst);
				numRec++;
				cur++;
				last = -1;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		@Override
		public boolean hasNext() {
			return cur < numRec;
		}

		@Override
		public boolean hasPrevious() {
			return cur > 0;
		}

		@Override
		public Address next() {
			if (!hasNext())
				throw new NoSuchElementException();

			Address tmp = new Address();
			try {
				raf.seek(cur * recSize);
				tmp = readAddressInToAddress(raf.getFilePointer());
			} catch (IOException e) {
				e.printStackTrace();
			}
			last = cur;
			cur++;
			return tmp;
		}

		@Override
		public int nextIndex() {
			return cur;
		}

		@Override
		public Address previous() {
			if (!hasPrevious())
				throw new NoSuchElementException();
			cur--;
			Address tmp = null;
			try {
				raf.seek(cur * recSize);
				tmp = readAddressInToAddress(raf.getFilePointer());
			} catch (IOException e) {
				e.printStackTrace();
			}
			last = cur;
			return tmp;
		}

		@Override
		public int previousIndex() {
			return cur - 1;
		}

		@Override
		public void remove() {
			if (last == -1)
				throw new IllegalStateException();
			try {
				ArrayList<Address> lst = fileToArrayList(); // Help ArrayList
				lst.remove(last);
				arrayListToFile(lst);
				numRec--;
				cur = last;
				last = -1;
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		@Override
		public void set(Address ad) {
			if (last == -1)
				throw new IllegalStateException();
			writeAddress(ad, last * recSize);
		}

		/** Reset all attributes and clean file */
		public void reset() throws IOException {
			while (hasNext()) {
				remove();
			}
			this.numRec = 0;
			this.cur = 0;
			this.last = -1;
			raf.setLength(0);
			raf.seek(0);
		}

		/** Copies file content into an auxiliary ArrayList */
		private ArrayList<Address> fileToArrayList() throws IOException {
			ArrayList<Address> lst = new ArrayList<>();
			raf.seek(0);
			while (raf.getFilePointer() < raf.length())
				lst.add(readAddressInToAddress(raf.getFilePointer()));
			return lst;
		}

		/** Save the auxiliary ArrayList content back to the file */
		private void arrayListToFile(ArrayList<Address> lst) throws IOException {
			raf.seek(0);
			raf.setLength(0);
			for (Address ad : lst)
				writeAddress(ad, raf.getFilePointer());
		}

	}

	/**
	 * Return 1 or -1 according to the compare method. Don't return 0 to keep all
	 * values
	 **/
	public class CompareAddressByStreet implements Comparator<Address> {

		@Override
		public int compare(Address ad1, Address ad2) {
			if (ad1.getStreet().compareTo(ad2.getStreet()) > 0) {
				return 1;
			} else {
				return -1;
			}
		}

	}
}