//Sapir Madmon. ID:209010230
import java.util.ArrayList;

import javafx.scene.layout.FlowPane;

public class Decorator {
	public static void decorator(FlowPane jpbutton, boolean update, ArrayList<CommandButton> commandBut) {
		if (update)
			for (int i = 0; i < commandBut.size(); i++)
				jpbutton.getChildren().add(commandBut.get(i));

		else
			for (int i = 0; i < commandBut.size(); i++)
				if (!commandBut.get(i).update)
					jpbutton.getChildren().add(commandBut.get(i));
	}
}
